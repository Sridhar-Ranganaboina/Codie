# Codex Handoff Prompt

You are implementing CIRP from this repository.

Read `README.md` first. Then read every document under `docs/` before making architectural changes.

This is an implementation assignment, not a design-only exercise.

Use the current source and tests of PR-Agent and OpenHands before deciding what to reuse.

Implement phase by phase. Do not skip required functionality, tests, security controls, evidence validation, cross-service analysis, or AWS deployment.

For every phase:

1. inspect
2. implement
3. test
4. fix
5. lint
6. type-check
7. security-check
8. document
9. report

Do not claim completion based on scaffolding or mocks.

Mocks are allowed only for external dependencies in tests.

The final system must pass the final acceptance checklist and the realistic polyglot E2E test.
