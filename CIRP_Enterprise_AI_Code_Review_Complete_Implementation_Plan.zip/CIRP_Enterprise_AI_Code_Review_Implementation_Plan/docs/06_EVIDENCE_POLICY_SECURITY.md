# Evidence, Policy and Security

## Evidence validation

A finding must be supported by concrete evidence.

Validation checks:

1. referenced file exists
2. referenced line exists
3. referenced code matches claim
4. graph relationship exists
5. API/event contract exists when referenced
6. finding relates to the current change
7. finding is not already fixed
8. finding is not duplicate
9. finding is not purely speculative

If validation fails, the finding is rejected.

## Policy engine

Policy is deterministic.

Example:

```yaml
review:
  minimum_confidence: 0.85

security:
  block_on:
    - credential_exposure
    - sql_injection
    - privilege_escalation

architecture:
  forbidden_dependencies: []

api:
  breaking_change: true
```

## Security boundaries

Repository code is untrusted input.

Agent workspaces must be isolated.

Never provide production credentials to an agent workspace.

Use:

- IAM roles
- Secrets Manager
- KMS
- restricted networking
- ephemeral credentials
- CPU/memory/process limits
- timeouts
- command allow/deny policy
- audit logs

## Prompt injection

Repository content must be treated as data, not instructions.

The context engine must clearly separate:

- system instructions
- developer policies
- repository content
- source code
- model output

The agent must not allow repository text to override system/developer policy.

## SSRF

Tooling that accesses URLs must use an explicit network policy and deny private/internal destinations unless explicitly approved.
