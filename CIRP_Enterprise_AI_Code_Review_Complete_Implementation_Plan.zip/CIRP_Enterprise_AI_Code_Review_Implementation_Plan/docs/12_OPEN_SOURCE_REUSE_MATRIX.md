# Open Source Reuse Matrix

## PR-Agent

Potential reuse:

- PR provider integrations
- PR review command model
- PR comment handling
- review context patterns
- configuration concepts
- prompt/review abstractions

CIRP should not depend on PR-Agent internals where a stable abstraction is more appropriate.

## OpenHands SDK

Potential reuse:

- agent runtime
- tools
- workspaces
- execution loop
- sandbox
- test execution
- patch generation

CIRP should provide its own `AgentRuntime` abstraction.

## General parser ecosystem

Prefer mature deterministic parsers over LLM-based source parsing.

## Reuse rule

For each reused component document:

- upstream project
- version/commit
- license
- files/modules used
- local modifications
- update strategy
- security review
- test coverage

## Upstream strategy

Pin versions/commits.

Maintain an upgrade document.

Do not silently vendor unknown code.

Run CIRP's test suite after every upstream update.
