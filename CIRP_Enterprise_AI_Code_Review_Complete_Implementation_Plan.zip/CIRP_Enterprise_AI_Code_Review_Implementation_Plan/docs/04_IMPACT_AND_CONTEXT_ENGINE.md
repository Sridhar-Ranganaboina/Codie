# Change Impact and Context Engine

## Impact radius

### R0

Directly changed symbols.

### R1

Direct callers, callees, interfaces, tests, contracts and resources.

### R2

Indirect dependencies.

### R3

Cross-service dependencies.

### R4

External contracts and externally consumed interfaces.

## Context construction

The context engine combines:

- PR diff
- changed symbols
- graph evidence
- affected services
- API contracts
- event contracts
- database schema
- tests
- static-analysis findings
- documentation
- relevant historical context
- repository policy

## Retrieval strategy

Graph retrieval answers deterministic relationship questions.

Vector retrieval answers semantic similarity questions.

Metadata filtering prevents retrieval from crossing repository/tenant boundaries.

## Context ranking

Suggested initial ranking factors:

- changed symbol: 1.00
- direct caller: 0.98
- API contract: 0.95
- direct test: 0.93
- event consumer: 0.90
- indirect dependency: 0.75
- documentation: 0.60

These are starting values, not immutable constants.

## Context provenance

Every context item must contain:

- repository
- commit
- file
- symbol
- line range
- source type
- retrieval method
- relevance score

## Token budget

The engine must:

- calculate estimated token size
- prioritize high-value evidence
- deduplicate content
- compress low-priority context
- enforce hard budgets
- report discarded context
