# AWS Deployment Plan

## Services

- API Gateway
- ECS/Fargate and/or EKS
- SQS
- S3
- Aurora PostgreSQL
- OpenSearch
- Secrets Manager
- KMS
- IAM
- CloudWatch
- EventBridge
- Step Functions where needed

## Networking

Prefer private subnets for internal services.

Use VPC endpoints/private connectivity where appropriate.

Restrict outbound access from agent workers.

## IAM

Use least-privilege roles.

Separate:

- API role
- ingestion role
- graph role
- review role
- sandbox role
- deployment role

Never use one broad administrative role for all components.

## Infrastructure

Terraform must support:

- dev
- staging
- production

State and secrets must not be committed to source control.

## Scaling

Workers should scale independently for:

- ingestion
- graph processing
- review processing
- embeddings
- agent execution

SQS queue depth should be usable as an autoscaling signal.

## Resilience

Implement:

- retries
- dead-letter queues
- idempotency keys
- correlation IDs
- timeout handling
- circuit breakers
- partial failure handling
- resumable ingestion
