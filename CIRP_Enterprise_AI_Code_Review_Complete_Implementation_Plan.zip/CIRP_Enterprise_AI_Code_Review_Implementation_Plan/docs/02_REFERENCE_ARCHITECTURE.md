# CIRP Reference Architecture

## Logical layers

1. Provider integrations
2. Review orchestration
3. Repository intelligence
4. Context engineering
5. Agent reasoning
6. Evidence validation
7. Policy enforcement
8. Output integrations
9. Observability and governance

## End-to-end flow

```text
Git provider
  -> webhook
  -> API
  -> queue
  -> orchestrator
  -> diff analysis
  -> graph/semantic retrieval
  -> impact analysis
  -> context construction
  -> review planning
  -> specialized agents
  -> evidence validation
  -> policy
  -> finding merger
  -> PR comments
```

## Data plane

S3 stores repository snapshots and generated artifacts.

PostgreSQL stores operational metadata.

The code graph is initially backed by PostgreSQL behind an abstraction. A future Neptune implementation may be added.

OpenSearch stores semantic vectors and searchable metadata.

SQS decouples ingestion and review work.

ECS/EKS runs stateless APIs and workers.

Step Functions can orchestrate long-running workflows.

## Control plane

The control plane contains:

- repository registration
- model configuration
- review policy
- service ownership
- security policy
- agent configuration
- cost limits
- tenant configuration
- audit configuration
