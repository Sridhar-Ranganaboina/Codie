# Codex Execution Protocol

## Objective

Codex is responsible for implementing the platform, not merely generating scaffolding.

## Required workflow

### Step 1 — Inspect

Inspect the repository and current open-source dependencies.

### Step 2 — Plan

Write/update the implementation plan and identify dependencies.

### Step 3 — Implement

Implement the smallest coherent production-quality increment.

### Step 4 — Test

Run all tests relevant to the increment.

### Step 5 — Fix

Do not proceed while failures introduced by the increment remain.

### Step 6 — Quality

Run:

- lint
- type checking
- security
- coverage

### Step 7 — Document

Update architecture/API/design documentation.

### Step 8 — Validate

Run an end-to-end scenario where appropriate.

### Step 9 — Commit

Use meaningful commits per phase.

## No fake completion

Do not:

- create empty classes
- return placeholder values
- use TODOs instead of required behavior
- silently disable tests
- mark unsupported features as implemented
- replace required functionality with mocks outside test-only code

Mocks are acceptable for external services in tests, not as substitutes for core implementation.

## Phase completion report

At the end of each phase report:

- files changed
- features implemented
- tests added
- test result
- coverage
- security result
- known limitations
- next phase
