# CI/CD and Operations

## Developer commands

```bash
make dev
make test
make test-unit
make test-integration
make test-functional
make test-e2e
make test-performance
make lint
make typecheck
make security
make build
```

## CI pipeline

```text
lint
format check
type check
unit
integration
security
coverage
build
functional
E2E
```

## Operational metrics

Track:

- reviews
- review duration
- ingestion duration
- graph query latency
- retrieval latency
- context construction latency
- model latency
- token usage
- cost
- finding counts
- validation rejection counts
- duplicate findings
- false-positive feedback
- queue depth
- worker failures

## Audit

Record:

- actor
- repository
- commit
- PR
- model
- model version
- prompt version
- context IDs
- tools invoked
- findings
- policy result
- final comments
- timestamps

Avoid storing unnecessary sensitive source content in telemetry.

## Feedback

Each finding should support:

- useful
- not useful
- false positive
- incorrect severity
- already fixed

Feedback should be linked to the exact finding/model/context version.
