# Final Acceptance Checklist

## Repository intelligence

- [ ] Java parsing
- [ ] TypeScript parsing
- [ ] React parsing
- [ ] Python parsing
- [ ] OpenAPI parsing
- [ ] GraphQL parsing
- [ ] Terraform parsing
- [ ] Kubernetes parsing
- [ ] Docker parsing
- [ ] incremental indexing
- [ ] symbol extraction
- [ ] graph persistence
- [ ] evidence-backed edges

## Impact

- [ ] R0
- [ ] R1
- [ ] R2
- [ ] R3
- [ ] R4
- [ ] API impact
- [ ] event impact
- [ ] DB impact
- [ ] test impact

## AI review

- [ ] correctness
- [ ] security
- [ ] architecture
- [ ] API
- [ ] event
- [ ] tests
- [ ] performance
- [ ] planner
- [ ] evidence validation
- [ ] duplicate removal
- [ ] policy enforcement

## Integrations

- [ ] GitHub
- [ ] PR-Agent reuse
- [ ] OpenHands adapter
- [ ] Bedrock
- [ ] Azure OpenAI

## Infrastructure

- [ ] Docker Compose
- [ ] Terraform
- [ ] S3
- [ ] SQS
- [ ] PostgreSQL/Aurora
- [ ] OpenSearch
- [ ] ECS/EKS
- [ ] Secrets Manager
- [ ] KMS
- [ ] IAM
- [ ] CloudWatch

## Quality

- [ ] unit tests
- [ ] integration tests
- [ ] functional tests
- [ ] E2E
- [ ] golden suite
- [ ] security tests
- [ ] performance tests
- [ ] coverage
- [ ] lint
- [ ] type checking

## Documentation

- [ ] README
- [ ] architecture
- [ ] graph
- [ ] impact
- [ ] context
- [ ] agents
- [ ] security
- [ ] deployment
- [ ] testing
- [ ] performance
- [ ] troubleshooting
- [ ] open-source licenses
