# Testing and Acceptance Strategy

## Test layers

### Unit

Core package logic with deterministic fixtures.

### Integration

Real local services or containers for:

- PostgreSQL
- OpenSearch
- S3-compatible storage
- SQS-compatible queue
- provider mocks

### Functional

Full feature scenarios using sample repositories.

### E2E

Webhook -> queue -> orchestration -> analysis -> LLM mock -> validation -> PR output.

### Security

Authentication, authorization, secret handling, sandboxing, prompt injection, SSRF, path traversal and command execution.

### Performance

10K, 100K, 500K and 1M+ LOC repositories.

## Golden tests

Each golden test contains:

```text
before/
after/
expected-findings.json
```

Mandatory golden scenarios:

- Java null bug
- Spring authorization issue
- SQL injection
- secret exposure
- REST breaking change
- GraphQL breaking change
- Kafka schema mismatch
- SQS/SNS contract mismatch
- React/backend mismatch
- N+1
- missing regression test
- circular dependency
- Terraform security issue

## Quality gates

Core package target: at least 85% automated unit coverage.

No phase is complete if:

- tests fail
- lint fails
- type checking fails
- security checks fail
- documentation is missing
- important functionality is mocked instead of implemented

## Real-model testing

CI should use deterministic mock LLMs.

Nightly or controlled integration environments should execute real Bedrock/Azure tests.

Model responses must not be treated as deterministic. Golden tests should validate structured behavior, evidence, required findings and forbidden unsupported findings with appropriate tolerances.
