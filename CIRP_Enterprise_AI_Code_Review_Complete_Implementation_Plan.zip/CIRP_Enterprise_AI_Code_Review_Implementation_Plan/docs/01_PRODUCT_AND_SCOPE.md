# CIRP Product and Scope

## Product objective

CIRP is a self-hostable enterprise code-intelligence and AI-review platform. It is designed for large polyglot systems where a pull request can affect UI components, backend services, APIs, events, databases, infrastructure, tests, and downstream consumers.

The platform must not depend on a single LLM vendor and must not treat an LLM as the source of truth for deterministic repository relationships.

## Core promise

For a change such as:

`React component -> API client -> Spring controller -> service -> database -> event -> downstream microservice`

CIRP should be able to discover the relevant impact chain and provide only the necessary context to review agents.

## Scope

### In scope

- PR review
- repository ingestion
- incremental indexing
- AST/symbol extraction
- code graph
- dependency analysis
- cross-service impact
- API contract analysis
- event contract analysis
- test impact analysis
- semantic code retrieval
- multi-agent review
- evidence validation
- security review
- performance review
- architecture review
- optional auto-fix
- GitHub integration
- AWS deployment
- Bedrock
- Azure OpenAI
- OpenHands integration
- PR-Agent reuse
- observability
- cost controls
- feedback loop
- enterprise policies

### Non-goals for initial release

- unrestricted autonomous production changes
- automatic main-branch modification
- unrestricted shell execution
- unrestricted internet access from agent sandboxes
- coupling the domain model to one LLM vendor
- using an LLM as the source of truth for dependency relationships
