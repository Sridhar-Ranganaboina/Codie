# Code Graph Schema

## Node types

- Repository
- Branch
- Commit
- Service
- Module
- Package
- File
- Class
- Interface
- Method
- Function
- Component
- API
- GraphQL operation
- Database
- Table
- Column
- Event
- Topic
- Queue
- Deployment
- Test
- Team
- Contract

## Edge types

- CONTAINS
- IMPORTS
- CALLS
- IMPLEMENTS
- EXTENDS
- EXPOSES
- CONSUMES
- PRODUCES
- READS
- WRITES
- TESTED_BY
- DEPENDS_ON
- DEPLOYED_AS
- OWNED_BY
- IMPLEMENTS_CONTRACT
- CONSUMES_CONTRACT

## Evidence model

Every relationship must be traceable to source evidence.

Example:

```json
{
  "source": "CustomerService.updateStatus",
  "target": "CustomerRepository.save",
  "type": "CALLS",
  "file": "CustomerService.java",
  "start_line": 172,
  "end_line": 172,
  "commit": "abc123",
  "confidence": 1.0
}
```

Graph confidence is not the same as LLM confidence. Deterministically extracted relationships should normally have high confidence; inferred relationships must be explicitly marked as inferred.

## Traversal requirements

Implement:

- callers
- callees
- direct dependencies
- reverse dependencies
- service dependencies
- API consumers
- event consumers
- affected tests
- dependency paths
- shortest explanatory paths
- configurable depth
- repository boundary traversal
