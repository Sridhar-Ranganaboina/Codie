# Detailed Implementation Backlog

## EPIC A — Foundation

- A1 repository structure
- A2 configuration
- A3 logging
- A4 correlation
- A5 database
- A6 migrations
- A7 API
- A8 Docker Compose
- A9 CI

## EPIC B — Provider Abstraction

- B1 LLM protocol
- B2 Bedrock provider
- B3 Azure OpenAI provider
- B4 mock provider
- B5 structured output
- B6 retries
- B7 circuit breaker
- B8 cost accounting
- B9 model routing
- B10 telemetry

## EPIC C — Repository Intelligence

- C1 repository registration
- C2 Git provider adapter
- C3 clone
- C4 checkout
- C5 language detection
- C6 parser orchestration
- C7 incremental indexing
- C8 snapshot storage
- C9 ingestion state

## EPIC D — Code Graph

- D1 node schema
- D2 edge schema
- D3 evidence
- D4 graph persistence
- D5 traversal
- D6 caller lookup
- D7 callee lookup
- D8 dependency lookup
- D9 service graph
- D10 API graph
- D11 event graph
- D12 test graph

## EPIC E — Semantic Search

- E1 semantic chunking
- E2 embedding provider
- E3 OpenSearch index
- E4 metadata filters
- E5 vector search
- E6 hybrid retrieval
- E7 cache

## EPIC F — Impact

- F1 changed files
- F2 changed symbols
- F3 R0
- F4 R1
- F5 R2
- F6 R3
- F7 R4
- F8 API impact
- F9 event impact
- F10 DB impact
- F11 test impact
- F12 impact explanation paths

## EPIC G — Context

- G1 context model
- G2 ranking
- G3 provenance
- G4 token estimator
- G5 budget
- G6 deduplication
- G7 compression
- G8 final context manifest

## EPIC H — Review

- H1 planner
- H2 correctness agent
- H3 security agent
- H4 API agent
- H5 event agent
- H6 architecture agent
- H7 test agent
- H8 performance agent

## EPIC I — Validation

- I1 finding schema
- I2 evidence checks
- I3 duplicate detection
- I4 confidence
- I5 policy
- I6 finding merge
- I7 output formatting

## EPIC J — PR

- J1 webhook
- J2 authentication
- J3 PR retrieval
- J4 inline comments
- J5 summary
- J6 rerun
- J7 feedback
- J8 dismissal

## EPIC K — Agent Runtime

- K1 runtime abstraction
- K2 OpenHands adapter
- K3 sandbox
- K4 command policy
- K5 test execution
- K6 patch generation
- K7 fix validation

## EPIC L — AWS

- L1 Terraform
- L2 VPC
- L3 IAM
- L4 S3
- L5 SQS
- L6 ECS/EKS
- L7 OpenSearch
- L8 Aurora
- L9 Secrets
- L10 KMS
- L11 CloudWatch
- L12 autoscaling
- L13 alarms

## EPIC M — Testing

- M1 unit
- M2 integration
- M3 functional
- M4 E2E
- M5 security
- M6 golden
- M7 performance
- M8 nightly real-model

## EPIC N — Operations

- N1 OpenTelemetry
- N2 metrics
- N3 dashboards
- N4 audit
- N5 feedback
- N6 cost reporting
- N7 operational runbooks
