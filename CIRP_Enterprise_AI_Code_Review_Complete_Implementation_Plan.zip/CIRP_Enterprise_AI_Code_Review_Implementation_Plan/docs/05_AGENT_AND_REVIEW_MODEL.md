# Review Agent Model

## Planner

The planner maps change characteristics to review capabilities.

Example:

```text
Java + API change + Kafka schema change
    -> correctness
    -> API contract
    -> event contract
    -> security
    -> test impact
```

## Specialized agents

### Correctness

Business logic, state transitions, null handling, exceptions, concurrency.

### Security

Authentication, authorization, injection, secrets, SSRF, deserialization, path traversal, insecure configuration.

### API

REST, OpenAPI and GraphQL compatibility.

### Event

Kafka/SQS/SNS schema and consumer compatibility.

### Architecture

Boundaries, dependency direction, layering, circular dependencies.

### Test

Coverage gaps, regression risk and missing scenarios.

### Performance

N+1, network amplification, blocking, expensive operations and resource misuse.

## Agent contract

Every agent receives a typed ReviewContext and returns typed Findings.

Agents do not directly post PR comments.

Agents do not directly mutate production systems.

Agents should not execute arbitrary commands unless an approved tool policy grants the capability.

## Model routing

The LLM gateway should allow different models for:

- summarization
- classification
- simple findings
- complex reasoning
- final validation

Model selection must be configurable and observable.
