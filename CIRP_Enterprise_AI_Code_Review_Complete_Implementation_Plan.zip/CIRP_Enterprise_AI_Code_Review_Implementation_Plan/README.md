# CIRP --- Enterprise AI Code Review & Code Intelligence Platform

## End-to-End Implementation Plan for Codex

**Version:** 1.0\
**Status:** Implementation Charter\
**Target:** Enterprise-grade, self-hostable, AWS-native AI code
intelligence and review platform

------------------------------------------------------------------------

# 1. Mission

Build an enterprise-grade, self-hostable AI code review and code
intelligence platform named **CIRP (Code Intelligence Review
Platform)**.

The platform must support complex enterprise systems containing:

-   React / TypeScript frontends
-   Java / Spring Boot microservices
-   Python services
-   Node.js services
-   REST APIs
-   GraphQL
-   OpenAPI
-   Kafka
-   SQS / SNS
-   PostgreSQL / Aurora
-   DynamoDB
-   Terraform
-   Kubernetes
-   Docker
-   multiple modules
-   multiple microservices
-   multiple repositories
-   cross-service contracts
-   shared libraries

The platform must go substantially beyond:

``` text
Git diff → LLM → PR comments
```

The central design principle is:

``` text
Deterministic code intelligence
        +
Code graph
        +
Change impact analysis
        +
Hybrid graph/semantic retrieval
        +
LLM reasoning
        +
Evidence validation
```

The LLM must not be the source of truth for deterministic repository
relationships.

------------------------------------------------------------------------

# 2. Existing Open Source Work to Reuse

Before implementing equivalent functionality, inspect and evaluate the
current versions of:

## PR-Agent

Repository:

https://github.com/The-PR-Agent/pr-agent

Use it for mature PR-review and repository-provider functionality where
appropriate.

Inspect its current:

-   PR parsing
-   GitHub integration
-   GitLab integration
-   Bitbucket integration
-   review commands
-   review prompts
-   context compression
-   configuration
-   Docker deployment
-   testing approach

Do not blindly copy code.

Preserve license and attribution requirements.

## OpenHands Software Agent SDK

Repository:

https://github.com/OpenHands/software-agent-sdk

Evaluate it for:

-   agent execution
-   tools
-   workspace management
-   code execution
-   test execution
-   patch generation
-   sandbox execution
-   agent/server integration

CIRP's code-intelligence layer must remain independent from OpenHands so
that the agent runtime can be replaced later.

------------------------------------------------------------------------

# 3. Target Architecture

``` text
                     GitHub / GitLab / Bitbucket
                              |
                              | PR Webhook
                              v
                       +--------------+
                       | API Gateway  |
                       +------+-------+
                              |
                              v
                     +-------------------+
                     | Review Orchestrator|
                     +---------+---------+
                               |
              +----------------+----------------+
              |                |                |
              v                v                v
        Change Analyzer   Code Intelligence   Static Analysis
              |                |                |
              |        +-------+-------+        |
              |        |               |        |
              |        v               v        |
              |    Code Graph      Vector Search|
              |        |               |        |
              +--------+---------------+--------+
                               |
                               v
                       Impact Analyzer
                               |
                               v
                        Context Engine
                               |
                               v
                        Review Planner
                               |
          +--------------------+--------------------+
          |                    |                    |
          v                    v                    v
    Correctness            Security            Architecture
       Agent                 Agent                Agent
          |                    |                    |
          v                    v                    v
      Test Agent           API Agent          Event Agent
          |                    |                    |
          +--------------------+--------------------+
                               |
                               v
                       Evidence Validator
                               |
                               v
                        Finding Merger
                               |
                               v
                         Policy Engine
                               |
                               v
                         GitHub Review
```

------------------------------------------------------------------------

# 4. Core Differentiators

CIRP must contain these first-class subsystems:

1.  Repository ingestion engine
2.  AST / symbol extraction engine
3.  Enterprise code graph
4.  Change impact engine
5.  Semantic code/document retrieval
6.  Context orchestration engine
7.  Review planner
8.  Specialized review agents
9.  Evidence validator
10. Finding merger
11. Policy engine
12. API contract analyzer
13. Event contract analyzer
14. Test impact analyzer
15. Security analysis
16. Performance analysis
17. LLM gateway
18. Agent execution/sandbox
19. PR integration
20. Feedback loop
21. Observability
22. Cost controls
23. Enterprise security
24. AWS deployment

------------------------------------------------------------------------

# 5. Recommended Technology Stack

## Backend

-   Python 3.12+
-   FastAPI
-   Pydantic
-   SQLAlchemy
-   PostgreSQL
-   asyncio
-   pytest
-   Ruff
-   mypy

## Frontend

-   React
-   TypeScript
-   Vite
-   TanStack Query
-   Monaco Editor where useful

## AWS

-   S3
-   SQS
-   ECS/Fargate and/or EKS
-   Aurora PostgreSQL
-   OpenSearch
-   Secrets Manager
-   KMS
-   IAM
-   CloudWatch
-   EventBridge
-   Step Functions where required

## Observability

-   OpenTelemetry
-   CloudWatch
-   Prometheus
-   Grafana

## LLM

-   Amazon Bedrock
-   Azure OpenAI
-   provider-neutral abstraction
-   deterministic mock provider for CI

------------------------------------------------------------------------

# 6. Repository Structure

Create the following monorepo:

``` text
cirp/
|
+-- apps/
|   +-- api/
|   +-- orchestrator/
|   +-- ingestion-worker/
|   +-- graph-worker/
|   +-- review-worker/
|   +-- web/
|
+-- packages/
|   +-- domain/
|   +-- llm-gateway/
|   +-- code-parser/
|   +-- code-graph/
|   +-- impact-engine/
|   +-- context-engine/
|   +-- review-engine/
|   +-- evidence-engine/
|   +-- policy-engine/
|   +-- security-engine/
|   +-- static-analysis/
|   +-- repository-adapters/
|   +-- contract-engine/
|   +-- test-intelligence/
|   +-- observability/
|
+-- integrations/
|   +-- github/
|   +-- gitlab/
|   +-- bitbucket/
|   +-- pr-agent/
|   +-- openhands/
|
+-- infra/
|   +-- terraform/
|   +-- docker/
|   +-- kubernetes/
|
+-- tests/
|   +-- unit/
|   +-- integration/
|   +-- functional/
|   +-- e2e/
|   +-- performance/
|   +-- security/
|   +-- golden/
|
+-- examples/
|   +-- java-microservices/
|   +-- react-spring/
|   +-- python-services/
|   +-- polyglot/
|
+-- docs/
|
+-- Makefile
+-- docker-compose.yml
+-- README.md
```

------------------------------------------------------------------------

# 7. Architectural Rules

## Rule 1 --- Deterministic before probabilistic

Use deterministic analysis for:

-   AST
-   symbols
-   imports
-   calls
-   dependencies
-   API definitions
-   event schemas
-   database relationships
-   test relationships
-   infrastructure relationships

Use LLMs for:

-   reasoning
-   semantic interpretation
-   explanation
-   remediation suggestions
-   architectural judgment

## Rule 2 --- No giant repository prompt

Never send the entire repository to an LLM.

Use:

``` text
PR diff
  |
changed symbols
  |
impact graph
  |
relevant context
  |
LLM
```

## Rule 3 --- Graph and vector search have different responsibilities

Graph:

-   who calls X?
-   what depends on X?
-   which service consumes event Y?
-   what APIs are exposed?
-   which tests cover X?

Vector search:

-   find semantically similar code
-   find relevant documentation
-   find similar implementations
-   find historical context

## Rule 4 --- Every AI finding needs evidence

An unsupported LLM claim must not become a PR comment.

------------------------------------------------------------------------

# 8. Phase 0 --- Repository Reconnaissance

Before implementation:

1.  Inspect the current repository.
2.  Inspect current PR-Agent source and tests.
3.  Inspect current OpenHands SDK source and tests.
4.  Identify reusable modules.
5.  Review licenses.
6.  Document dependencies.
7.  Document integration points.
8.  Document risks.
9.  Produce architecture diagrams.
10. Produce an implementation backlog.

Do not assume APIs from memory.

Use the actual checked-out source.

Deliverables:

``` text
docs/open-source-analysis.md
docs/architecture.md
docs/reuse-matrix.md
docs/license-matrix.md
docs/implementation-roadmap.md
```

------------------------------------------------------------------------

# 9. Phase 1 --- Foundation

Implement:

-   project structure
-   configuration
-   environment validation
-   dependency injection
-   structured logging
-   correlation IDs
-   API skeleton
-   database migrations
-   health endpoint
-   readiness endpoint
-   error model
-   exception handling
-   Docker Compose
-   CI pipeline

Tests:

-   configuration tests
-   startup tests
-   health tests
-   error-handling tests

------------------------------------------------------------------------

# 10. Phase 2 --- LLM Gateway

Create:

``` text
packages/llm-gateway/
```

Interface:

``` python
class LLMProvider(Protocol):
    async def chat(
        self,
        messages: list[Message],
        *,
        model: str,
        temperature: float = 0,
        response_schema: type[BaseModel] | None = None,
    ) -> LLMResponse:
        ...
```

Implement:

``` text
BedrockProvider
AzureOpenAIProvider
MockLLMProvider
```

Capabilities:

-   structured output
-   JSON schema
-   retries
-   timeout
-   exponential backoff
-   circuit breaker
-   token accounting
-   cost accounting
-   model routing
-   request IDs
-   tracing
-   cancellation
-   error normalization

No domain package may directly import the Bedrock or Azure SDK.

------------------------------------------------------------------------

# 11. Phase 3 --- Repository Management

Create repository entities:

``` text
Repository
RepositoryBranch
RepositoryCommit
RepositorySnapshot
RepositoryService
RepositoryOwner
```

Support:

-   repository registration
-   Git URL
-   provider
-   branch
-   commit
-   clone
-   checkout
-   authentication
-   snapshot
-   incremental indexing
-   ingestion state
-   retry
-   idempotency

Use S3 for durable snapshots/artifacts.

------------------------------------------------------------------------

# 12. Phase 4 --- Language and AST Analysis

Initial languages:

-   Java
-   TypeScript
-   JavaScript
-   Python
-   JSON
-   YAML
-   Terraform

Extract:

``` text
File
Module
Package
Class
Interface
Function
Method
Component
Import
Call
Inheritance
Annotation
Route
API
Database access
Event producer
Event consumer
Test
```

Java-specific extraction:

-   Spring controllers
-   REST mappings
-   services
-   repositories
-   dependency injection
-   Kafka producers/consumers

TypeScript/React:

-   components
-   hooks
-   API clients
-   routes
-   Redux actions
-   GraphQL operations

Python:

-   modules
-   classes
-   functions
-   imports
-   calls
-   FastAPI/Flask routes

Infrastructure:

-   Kubernetes
-   Docker
-   Terraform
-   OpenAPI

Use deterministic parsers.

Do not use an LLM to create basic source relationships.

------------------------------------------------------------------------

# 13. Phase 5 --- Enterprise Code Graph

Graph node types:

``` text
Repository
Service
Module
Package
File
Class
Interface
Method
Function
Component
API
Database
Table
Event
Topic
Queue
Deployment
Test
Team
```

Relationship types:

``` text
CONTAINS
IMPORTS
CALLS
IMPLEMENTS
EXTENDS
EXPOSES
CONSUMES
PRODUCES
READS
WRITES
TESTED_BY
DEPENDS_ON
DEPLOYED_AS
OWNED_BY
```

Each edge must include evidence:

``` json
{
  "source": "CustomerService.updateStatus",
  "target": "CustomerRepository.save",
  "type": "CALLS",
  "confidence": 1.0,
  "file": "CustomerService.java",
  "line": 172,
  "commit": "abc123"
}
```

Implement graph APIs:

``` text
get_callers()
get_callees()
get_dependencies()
get_reverse_dependencies()
get_service_dependencies()
get_api_consumers()
get_event_consumers()
get_affected_tests()
get_impact_radius()
```

Create an interface so the graph implementation can evolve:

``` python
class CodeGraphStore(Protocol):
    ...
```

Start with PostgreSQL-backed storage if practical.

Keep Neptune support as an implementation option rather than hard-coding
it into domain logic.

------------------------------------------------------------------------

# 14. Phase 6 --- Semantic Index

Create semantic chunks around symbols rather than arbitrary token
windows.

Example:

``` json
{
  "repository": "customer-service",
  "commit": "abc123",
  "service": "customer-service",
  "file": "CustomerService.java",
  "symbol": "updateStatus",
  "type": "method",
  "language": "java",
  "start_line": 145,
  "end_line": 198,
  "content": "...",
  "dependencies": [
    "CustomerRepository",
    "EventPublisher"
  ]
}
```

Store:

-   embeddings
-   source
-   commit
-   file
-   symbol
-   language
-   service
-   ownership
-   line range
-   graph references

Use OpenSearch.

Implement:

-   indexing
-   deletion
-   update
-   semantic search
-   metadata filters
-   hybrid search

------------------------------------------------------------------------

# 15. Phase 7 --- Change Impact Engine

Given a PR:

``` text
PR
 |
diff
 |
changed files
 |
changed symbols
```

Calculate:

``` text
R0 = changed symbols
R1 = direct callers/dependencies
R2 = indirect dependencies
R3 = cross-service dependencies
R4 = external contracts
```

Output:

``` json
{
  "changed_symbols": [],
  "direct_impact": [],
  "indirect_impact": [],
  "cross_service_impact": [],
  "api_impact": [],
  "event_impact": [],
  "database_impact": [],
  "test_impact": []
}
```

Traversal depth must be configurable.

The impact engine must provide explainable paths:

``` text
CustomerStatus.tsx
 -> customerApi.ts
 -> CustomerController.java
 -> CustomerService.java
 -> EventPublisher
 -> CustomerUpdated
 -> NotificationService
```

------------------------------------------------------------------------

# 16. Phase 8 --- API and Contract Intelligence

Support:

-   REST
-   OpenAPI
-   GraphQL

Detect:

-   endpoint changes
-   request changes
-   response changes
-   removed fields
-   renamed fields
-   type changes
-   required-field changes
-   authentication changes
-   breaking changes

The system must identify consumers through the graph.

------------------------------------------------------------------------

# 17. Phase 9 --- Event Contract Intelligence

Support:

-   Kafka
-   SQS
-   SNS

Detect:

-   event schema changes
-   removed fields
-   renamed fields
-   type changes
-   producer/consumer mismatch
-   incompatible evolution

Example:

``` text
OrderService
   |
   | OrderCreated
   v
Kafka
   |
   +--> BillingService
   |
   +--> AnalyticsService
   |
   +--> NotificationService
```

If the producer changes the event, all consumers must be evaluated.

------------------------------------------------------------------------

# 18. Phase 10 --- Test Intelligence

Identify:

-   unit tests
-   integration tests
-   API tests
-   component tests
-   contract tests
-   end-to-end tests

Map:

``` text
changed symbol -> tests
```

Detect:

-   changed behavior without tests
-   uncovered branches
-   missing regression tests
-   affected integration tests

Produce evidence-backed findings.

------------------------------------------------------------------------

# 19. Phase 11 --- Context Engine

The Context Engine decides what the LLM sees.

Inputs:

-   PR diff
-   changed symbols
-   graph impact
-   API contracts
-   event contracts
-   database schema
-   tests
-   documentation
-   static analysis
-   ownership
-   relevant history

Output:

``` json
{
  "files": [],
  "symbols": [],
  "contracts": [],
  "tests": [],
  "documentation": [],
  "graph_evidence": [],
  "token_budget": 80000
}
```

Implement relevance scoring.

Example:

``` text
Changed method       1.00
Direct caller        0.98
API contract         0.95
Direct test          0.93
Event consumer       0.90
Indirect caller      0.75
Documentation        0.60
```

Implement:

-   token budgets
-   truncation
-   prioritization
-   deduplication
-   context compression
-   context provenance

Every context item must retain its source.

------------------------------------------------------------------------

# 20. Phase 12 --- Static Analysis

Integrate appropriate open-source tools where available.

Potential categories:

-   SAST
-   dependency scanning
-   secret scanning
-   IaC scanning
-   linting
-   type checking

The AI should consume deterministic findings rather than reproduce them
unnecessarily.

Static-analysis results must be normalized into a common schema.

------------------------------------------------------------------------

# 21. Phase 13 --- Review Planner

Create a Review Planner.

Example output:

``` json
{
  "review_types": [
    "correctness",
    "security",
    "api_contract",
    "event_contract",
    "test_coverage"
  ],
  "required_context": [
    "CustomerService.updateStatus",
    "CustomerController",
    "NotificationService"
  ]
}
```

Only registered capabilities may be invoked.

The planner must not be allowed to arbitrarily execute shell commands.

------------------------------------------------------------------------

# 22. Phase 14 --- Review Agents

Implement:

## Correctness Agent

Detect:

-   incorrect logic
-   null handling
-   state errors
-   race conditions
-   exception handling
-   invalid assumptions

## Security Agent

Detect:

-   injection
-   authorization issues
-   authentication issues
-   secrets
-   SSRF
-   path traversal
-   unsafe deserialization
-   insecure configuration

Combine AI with deterministic scanners.

## API Agent

Detect:

-   REST breaking changes
-   OpenAPI mismatch
-   GraphQL breaking changes
-   consumer incompatibility

## Event Agent

Detect:

-   Kafka schema changes
-   SQS/SNS contract changes
-   producer/consumer incompatibility

## Architecture Agent

Detect:

-   circular dependencies
-   service boundary violations
-   layering violations
-   forbidden dependencies
-   architectural policy violations

## Test Agent

Detect:

-   missing tests
-   missing edge cases
-   insufficient regression coverage

## Performance Agent

Detect:

-   N+1 queries
-   unnecessary network calls
-   expensive loops
-   blocking operations
-   excessive LLM calls
-   inefficient data access

------------------------------------------------------------------------

# 23. Phase 15 --- Evidence Validator

This is mandatory.

Every finding must contain:

``` json
{
  "file": "...",
  "start_line": 123,
  "end_line": 130,
  "reason": "...",
  "evidence": []
}
```

Validate:

1.  File exists.
2.  Line exists.
3.  Code matches the claim.
4.  Graph relationship exists.
5.  Contract exists if referenced.
6.  Finding is relevant to the PR.
7.  Finding isn't already fixed.
8.  Finding isn't duplicate.
9.  Finding isn't merely speculative.

If validation fails:

``` text
Reject finding.
```

Do not post it to the PR.

------------------------------------------------------------------------

# 24. Finding Schema

Use structured findings:

``` json
{
  "id": "finding-123",
  "category": "API_CONTRACT",
  "severity": "HIGH",
  "confidence": 0.94,
  "title": "Breaking response contract",
  "file": "CustomerController.java",
  "start_line": 142,
  "end_line": 148,
  "description": "...",
  "evidence": [
    {
      "file": "CustomerController.java",
      "line": 145
    },
    {
      "file": "customer.yaml",
      "line": 214
    }
  ],
  "suggested_fix": "...",
  "validated": true
}
```

------------------------------------------------------------------------

# 25. Finding Merger

Multiple agents may report the same issue.

Implement:

1.  deterministic duplicate keys
2.  file/line/category grouping
3.  semantic similarity
4.  evidence merging
5.  severity reconciliation
6.  confidence reconciliation

Do not generate duplicate PR comments.

------------------------------------------------------------------------

# 26. Policy Engine

Create a deterministic policy layer.

Example:

``` yaml
review:
  minimum_confidence: 0.85

security:
  block_on:
    - credential_exposure
    - sql_injection
    - privilege_escalation

architecture:
  enforce:
    - service_boundary
    - approved_dependencies

api:
  breaking_change: true
```

The LLM does not define policy.

The policy engine evaluates findings.

------------------------------------------------------------------------

# 27. PR Integration

Support:

-   GitHub webhook
-   GitHub App authentication
-   PR metadata
-   PR diff
-   inline comments
-   summary comment
-   review status
-   rerun
-   finding dismissal
-   developer feedback

Where practical, reuse PR-Agent's existing mature implementation.

Commands:

``` text
/review
/review-security
/review-architecture
/review-tests
/review-api
/review-full
```

------------------------------------------------------------------------

# 28. OpenHands Integration

Evaluate the current OpenHands SDK for:

-   sandbox workspace
-   agent execution
-   test execution
-   patch generation
-   optional fix generation

Keep the integration behind:

``` python
class AgentRuntime(Protocol):
    ...
```

Potential implementations:

``` text
OpenHandsRuntime
LocalSandboxRuntime
MockAgentRuntime
```

No domain package should depend directly on OpenHands.

------------------------------------------------------------------------

# 29. Auto-Fix

Implement as an optional capability.

Flow:

``` text
Finding
  |
  v
Fix Agent
  |
  v
Patch
  |
  v
Sandbox
  |
  +-- tests
  +-- lint
  +-- static analysis
  +-- review
  |
  v
Validated Patch
  |
  v
Proposed Branch / Commit
```

Never modify the main branch automatically.

------------------------------------------------------------------------

# 30. Secure Agent Sandbox

Every agent execution must have:

-   isolated filesystem
-   restricted network
-   no production credentials
-   short-lived credentials
-   CPU limits
-   memory limits
-   process limits
-   execution timeout
-   command policy
-   audit logs

Use ephemeral Docker/Kubernetes workspaces where appropriate.

------------------------------------------------------------------------

# 31. AWS Architecture

Target:

``` text
GitHub
  |
  v
API Gateway
  |
  v
SQS
  |
  v
ECS/EKS Orchestrator
  |
  +----> S3
  |
  +----> Aurora PostgreSQL
  |
  +----> OpenSearch
  |
  +----> SQS workers
  |
  +----> Step Functions
  |
  v
LLM Gateway
  |
  +----> Bedrock
  |
  +----> Azure OpenAI
```

Use private networking and IAM wherever appropriate.

------------------------------------------------------------------------

# 32. Terraform

Create:

``` text
infra/terraform/
  vpc.tf
  ecs.tf
  eks.tf
  s3.tf
  sqs.tf
  opensearch.tf
  postgres.tf
  iam.tf
  secrets.tf
  kms.tf
  cloudwatch.tf
  alarms.tf
  variables.tf
  outputs.tf
```

Environments:

``` text
dev
staging
prod
```

Do not hard-code secrets.

------------------------------------------------------------------------

# 33. Observability

Use OpenTelemetry.

Track:

``` text
review_count
review_duration
ingestion_duration
graph_query_latency
retrieval_latency
context_build_latency
llm_latency
tokens
cost
finding_count
validated_findings
rejected_findings
duplicate_findings
false_positive_feedback
agent_usage
model_usage
```

Add structured logs.

Every review must have a correlation ID.

------------------------------------------------------------------------

# 34. Cost Controls

Implement:

``` text
maximum PR cost
maximum LLM calls
maximum tokens
maximum context size
maximum agent count
model routing
embedding cache
context cache
repository snapshot cache
```

Example:

``` yaml
review:
  max_cost_usd: 2.00
  max_llm_calls: 12
  max_context_tokens: 100000
```

All values must be configurable.

------------------------------------------------------------------------

# 35. Feedback Loop

Every finding should allow:

``` text
Useful
Not useful
False positive
Already fixed
Incorrect severity
```

Store:

``` text
finding
context
model
prompt version
repository
commit
feedback
```

Use feedback to improve:

-   ranking
-   thresholds
-   prompts
-   retrieval
-   policies

Do not automatically train a model from unreviewed feedback.

------------------------------------------------------------------------

# 36. Testing Strategy

No feature is complete without automated tests.

## Unit tests

Target at least 85% coverage for core packages.

Mandatory coverage:

-   parser
-   graph
-   graph traversal
-   impact engine
-   context ranking
-   LLM gateway
-   policy engine
-   evidence validator
-   finding merger
-   contract engine

## Integration tests

Test:

-   PostgreSQL
-   OpenSearch
-   S3
-   SQS
-   Git provider mocks
-   Bedrock mock
-   Azure OpenAI mock

## Functional tests

Use realistic example repositories.

## E2E

Test:

``` text
PR
 |
Webhook
 |
SQS
 |
Orchestrator
 |
Graph
 |
Impact
 |
Context
 |
LLM
 |
Validation
 |
PR comment
```

## Security tests

Test:

-   authentication
-   authorization
-   secret handling
-   sandbox isolation
-   SSRF
-   command injection
-   malicious repository
-   malicious prompt content
-   path traversal

------------------------------------------------------------------------

# 37. Golden Test Suite

Create:

``` text
tests/golden/
```

Each test case:

``` text
before/
after/
expected-findings.json
```

Mandatory scenarios:

``` text
api-breaking/
event-contract/
sql-injection/
authorization/
secret-exposure/
java-null/
spring-security/
react-api-mismatch/
n-plus-one/
missing-test/
circular-dependency/
terraform-security/
```

Every model/prompt/context change must run the golden suite.

------------------------------------------------------------------------

# 38. Example Polyglot Test Repository

Create a realistic repository:

``` text
examples/polyglot/
|
+-- customer-ui/
|   +-- React/TypeScript
|
+-- customer-service/
|   +-- Java/Spring Boot
|
+-- notification-service/
|   +-- Java
|
+-- analytics-service/
|   +-- Python
|
+-- contracts/
|   +-- OpenAPI
|   +-- event schemas
|
+-- infrastructure/
|   +-- Terraform
|   +-- Kubernetes
|
+-- database/
|   +-- PostgreSQL schema
|
+-- tests/
```

Introduce intentional defects.

------------------------------------------------------------------------

# 39. Mandatory Functional Scenarios

## Scenario 1 --- Java logic defect

Change:

``` text
CustomerService.updateStatus()
```

Expected:

-   changed symbol detected
-   callers identified
-   tests identified
-   correctness finding generated
-   evidence validated

## Scenario 2 --- React/API mismatch

Change React API request.

Expected:

-   backend API discovered
-   OpenAPI discovered
-   mismatch detected

## Scenario 3 --- Event contract break

Change event schema.

Expected:

-   producer identified
-   consumers identified
-   compatibility evaluated
-   finding generated

## Scenario 4 --- Authorization defect

Remove authorization.

Expected:

-   static analysis
-   security agent
-   evidence validation
-   security finding

## Scenario 5 --- N+1

Introduce inefficient database access.

Expected:

-   performance finding

## Scenario 6 --- Missing regression test

Change business behavior without tests.

Expected:

-   test agent finding

## Scenario 7 --- Cross-service impact

Change a shared API.

Expected:

-   impacted services identified
-   affected consumers included in context

------------------------------------------------------------------------

# 40. Performance Benchmarks

Benchmark:

``` text
10K LOC
100K LOC
500K LOC
1M+ LOC
```

Measure:

-   full indexing
-   incremental indexing
-   graph construction
-   graph query
-   vector retrieval
-   context construction
-   LLM latency
-   complete review latency
-   memory
-   CPU
-   cost

Implement:

-   caching
-   incremental indexing
-   parallel parsing
-   embedding cache
-   snapshot cache
-   concurrency controls
-   token budgets

Document actual measurements rather than making unsupported performance
claims.

------------------------------------------------------------------------

# 41. Local Development

Provide:

``` bash
make dev
make test
make test-unit
make test-integration
make test-functional
make test-e2e
make test-performance
make lint
make typecheck
make security
make build
```

`make dev` should start:

``` text
API
orchestrator
workers
PostgreSQL
OpenSearch
LocalStack
frontend
```

Use Docker Compose.

CI must not require real Bedrock or Azure credentials.

------------------------------------------------------------------------

# 42. CI/CD

Pipeline:

``` text
PR
 |
 +-- lint
 +-- format
 +-- typecheck
 +-- unit tests
 +-- integration tests
 +-- functional tests
 +-- security scan
 +-- coverage
 +-- build
 +-- E2E
```

Add nightly:

``` text
real-model golden tests
performance tests
```

------------------------------------------------------------------------

# 43. Documentation

Create:

``` text
README.md
docs/
  architecture.md
  open-source-analysis.md
  code-graph.md
  impact-analysis.md
  context-engine.md
  review-agents.md
  evidence-validation.md
  contract-analysis.md
  test-intelligence.md
  llm-gateway.md
  agent-runtime.md
  security.md
  deployment.md
  local-development.md
  testing.md
  performance.md
  troubleshooting.md
  contributing.md
```

Create C4:

``` text
C4 Context
C4 Container
C4 Component
```

Create sequence diagrams for:

``` text
PR review
repository ingestion
cross-service impact
auto-fix
agent execution
```

------------------------------------------------------------------------

# 44. Development Process for Codex

Do not implement the entire platform blindly in one pass.

Work in phases:

``` text
Phase 0  Reconnaissance
Phase 1  Foundation
Phase 2  LLM Gateway
Phase 3  Repository Ingestion
Phase 4  AST/Symbol Analysis
Phase 5  Code Graph
Phase 6  Impact Engine
Phase 7  Semantic Retrieval
Phase 8  Context Engine
Phase 9  Review Planner
Phase 10 Review Agents
Phase 11 Evidence Validator
Phase 12 PR Integration
Phase 13 OpenHands
Phase 14 Auto-Fix
Phase 15 Security
Phase 16 Testing
Phase 17 Performance
Phase 18 AWS
Phase 19 Observability
Phase 20 Final Validation
```

At the end of every phase:

``` text
implement
  |
run tests
  |
fix failures
  |
lint
  |
type-check
  |
security scan
  |
update documentation
  |
review architecture
  |
commit
  |
next phase
```

Never skip failing tests to advance.

------------------------------------------------------------------------

# 45. Definition of Done

A feature is not complete unless:

1.  implementation exists
2.  unit tests exist
3.  integration tests exist where appropriate
4.  failure cases are tested
5.  lint passes
6.  type checking passes
7.  security checks pass
8.  observability exists
9.  documentation is updated
10. existing tests remain green

Do not mark functionality complete based only on a happy-path demo.

------------------------------------------------------------------------

# 46. Final Acceptance Test

The final platform must process a realistic polyglot repository
containing:

-   React frontend
-   Spring Boot backend
-   Python service
-   PostgreSQL
-   Kafka
-   REST/OpenAPI
-   Docker
-   Kubernetes
-   multiple services

Create a PR that intentionally introduces multiple defects across
service boundaries.

The system must:

1.  receive the webhook
2.  retrieve the PR
3.  identify changed files
4.  identify changed symbols
5.  update/consult the code graph
6.  calculate R0-R4 impact
7.  discover affected services
8.  discover API/event consumers
9.  identify affected tests
10. run static analysis
11. build relevant context
12. select appropriate agents
13. invoke Bedrock or Azure OpenAI through the gateway
14. generate structured findings
15. validate evidence
16. remove duplicates
17. apply policy
18. post useful inline comments
19. produce a summary
20. record telemetry
21. record cost
22. preserve audit information
23. pass all automated acceptance tests

------------------------------------------------------------------------

# 47. Non-Goals for the First Production Release

Do not compromise the core implementation to add:

-   arbitrary autonomous production changes
-   automatic main-branch modification
-   uncontrolled shell execution
-   unrestricted network access
-   model-specific domain coupling
-   a giant repository prompt
-   LLM-generated source-of-truth dependency graphs

These can be added later under explicit governance.

------------------------------------------------------------------------

# 48. Final Architecture Principle

The final system should be:

``` text
                    CIRP
                     |
        +------------+------------+
        |                         |
 Open-source foundation       CIRP intelligence
        |                         |
   PR-Agent                Enterprise Code Graph
   OpenHands               Change Impact Engine
        |                  Context Engine
        |                  Contract Engine
        |                  Evidence Validator
        |                  Policy Engine
        |                         |
        +------------+------------+
                     |
                 LLM Gateway
                /           \
           Bedrock       Azure OpenAI
                     |
                Review Agents
                     |
              Validated Findings
                     |
                GitHub Review
```

The primary intellectual property should be the combination of:

``` text
Code Graph
+
Impact Engine
+
Context Engine
+
Contract Intelligence
+
Evidence Validation
+
Enterprise Policy
```

The LLM provider and agent runtime should remain replaceable.

------------------------------------------------------------------------

# 49. Final Codex Instruction

Implement this platform end-to-end.

Do not reduce the scope by replacing major components with placeholders.

Do not omit tests.

Do not omit cross-service analysis.

Do not omit evidence validation.

Do not omit security.

Do not omit observability.

Do not omit AWS deployment.

Do not claim completion because the API starts or one PR review works.

Use existing open-source work where it is mature and appropriate, and
build the differentiated intelligence layer around it.

At completion, the repository must be buildable, testable, locally
runnable, deployable to AWS, and demonstrable against the supplied
polyglot test repositories.

Every major architectural decision must be documented.

Every production-facing component must have automated tests.

The final acceptance suite is the authority for completion.
