from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pr_agent.algo.comment_identity import PRReviewHeader, PRReviewIdentity
from pr_agent.algo.inline_comment_dedup import (
    body_with_markers,
    get_inline_comment_store,
    key_issue_fingerprint,
)
from pr_agent.algo.types import FilePatchInfo
from pr_agent.algo.utils import convert_to_markdown_v2
from pr_agent.config_loader import get_settings
from pr_agent.git_providers.azuredevops_provider import AzureDevopsProvider
from pr_agent.git_providers.github_provider import GithubProvider
from pr_agent.git_providers.gitlab_provider import GitLabProvider
from pr_agent.tools.pr_reviewer import PRReviewer, _review_failure_comment

_VALID_PREDICTION = "review:\n  summary: prediction"


def _make_reviewer(git_provider=None):
    reviewer = PRReviewer.__new__(PRReviewer)
    reviewer.git_provider = git_provider or MagicMock()
    reviewer.pr_url = "https://example/pr/1"
    return reviewer


def _make_prediction_reviewer(git_provider=None):
    reviewer = _make_reviewer(git_provider)
    reviewer.token_handler = MagicMock()
    reviewer.remaining_files_list = []
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.prediction = None
    return reviewer


def test_review_failure_comment_publishes_known_reason_without_raw_error():
    settings = get_settings()
    original = settings.pr_reviewer.get("publish_error_details", False)
    provider_error = RuntimeError(
        "AnthropicException: Your credit balance is too low; key=sk-ant-secret; request_id=req_sensitive"
    )
    review_error = RuntimeError("Failed to generate prediction with any model")
    review_error.__cause__ = provider_error
    try:
        settings.pr_reviewer.publish_error_details = True
        comment = _review_failure_comment(review_error)
    finally:
        settings.pr_reviewer.publish_error_details = original

    assert comment == (
        "Failed to review PR\n\n"
        "**Reason:** The model provider rejected the request because the API account has insufficient credits. "
        "Add credits, then retry the command."
    )
    assert "sk-ant-secret" not in comment
    assert "req_sensitive" not in comment


def test_review_failure_comment_does_not_publish_unknown_exception_text():
    settings = get_settings()
    original = settings.pr_reviewer.get("publish_error_details", False)
    try:
        settings.pr_reviewer.publish_error_details = True
        comment = _review_failure_comment(RuntimeError("Authorization: Bearer secret-token user@example.com"))
    finally:
        settings.pr_reviewer.publish_error_details = original

    assert comment == (
        "Failed to review PR\n\n"
        "**Reason:** PR-Agent encountered an unexpected internal error. "
        "Check the PR-Agent service logs for details."
    )
    assert "secret-token" not in comment
    assert "user@example.com" not in comment


def test_review_failure_comment_treats_quoted_false_as_disabled():
    settings = get_settings()
    original = settings.pr_reviewer.get("publish_error_details", False)
    try:
        settings.pr_reviewer.publish_error_details = "false"
        comment = _review_failure_comment(RuntimeError("Your credit balance is too low"))
    finally:
        settings.pr_reviewer.publish_error_details = original

    assert comment == "Failed to review PR"


@pytest.mark.asyncio
async def test_prepare_prediction_requests_remaining_files_and_preserves_tuple_result():
    reviewer = _make_prediction_reviewer()
    reviewer._get_prediction = AsyncMock(return_value=_VALID_PREDICTION)

    with patch(
        "pr_agent.tools.pr_reviewer.get_pr_diff",
        return_value=("diff", ["src/one.py", "docs/two.md"]),
    ) as get_pr_diff:
        await reviewer._prepare_prediction("model")

    get_pr_diff.assert_called_once_with(
        reviewer.git_provider,
        reviewer.token_handler,
        "model",
        add_line_numbers_to_hunks=True,
        disable_extra_lines=False,
        return_remaining_files=True,
    )
    assert reviewer.patches_diff == "diff"
    assert reviewer.remaining_files_list == ["src/one.py", "docs/two.md"]
    assert reviewer.prediction == _VALID_PREDICTION


@pytest.mark.asyncio
async def test_prepare_prediction_accepts_full_diff_string_when_token_budget_is_sufficient():
    reviewer = _make_prediction_reviewer()
    reviewer._get_prediction = AsyncMock(return_value=_VALID_PREDICTION)

    with patch("pr_agent.tools.pr_reviewer.get_pr_diff", return_value="diff"):
        await reviewer._prepare_prediction("model")

    assert reviewer.patches_diff == "diff"
    assert reviewer.remaining_files_list == []
    assert reviewer.prediction == _VALID_PREDICTION


@pytest.mark.asyncio
async def test_prepare_prediction_keeps_incremental_review_compatible_with_tuple_result():
    reviewer = _make_prediction_reviewer()
    reviewer.incremental = SimpleNamespace(is_incremental=True)
    reviewer._get_prediction = AsyncMock(return_value=_VALID_PREDICTION)

    with patch("pr_agent.tools.pr_reviewer.get_pr_diff", return_value=("diff", ["skipped.py"])):
        await reviewer._prepare_prediction("model")

    assert reviewer.patches_diff == "diff"
    assert reviewer.remaining_files_list == ["skipped.py"]
    assert reviewer.prediction == _VALID_PREDICTION


@pytest.mark.asyncio
async def test_final_review_fit_rejects_untracked_diff_clipping():
    reviewer = _make_prediction_reviewer()
    reviewer.vars = {"diff": ""}
    reviewer.ai_handler = SimpleNamespace(chat_completion=AsyncMock())

    class ClippingBudget:
        def fit_prompt_variable(self, _variables, _name, optional_text, **_kwargs):
            return SimpleNamespace(
                optional_text=optional_text[:-1],
                system_prompt="system",
                user_prompt="user",
            )

    with patch(
        "pr_agent.tools.pr_reviewer.AttemptTokenBudget.for_attempt",
        return_value=ClippingBudget(),
    ):
        with pytest.raises(ValueError, match="complete packed review diff"):
            await reviewer._get_prediction("fallback-model", "complete-diff")

    reviewer.ai_handler.chat_completion.assert_not_awaited()


def _render_review(reviewer, remaining_files, supports_gfm_markdown=False):
    reviewer.prediction = "review:\n  summary: test"
    reviewer.remaining_files_list = remaining_files
    reviewer.git_provider.get_diff_files.return_value = []
    reviewer.git_provider.is_supported.return_value = supports_gfm_markdown
    reviewer.set_review_labels = MagicMock()

    with (
        patch("pr_agent.tools.pr_reviewer.load_yaml", return_value={"review": {"summary": "test"}}),
        patch("pr_agent.tools.pr_reviewer.github_action_output"),
        patch("pr_agent.tools.pr_reviewer.convert_to_markdown_v2", return_value="original review"),
    ):
        return reviewer._prepare_pr_review()


def test_prepare_pr_review_appends_complete_coverage_footer():
    reviewer = _make_prediction_reviewer()
    settings = get_settings()
    original_enable_review_coverage_footer = settings.pr_reviewer.enable_review_coverage_footer

    try:
        settings.pr_reviewer.enable_review_coverage_footer = True
        review = _render_review(reviewer, ["src/one.py", "nested/two.md"])
    finally:
        settings.pr_reviewer.enable_review_coverage_footer = original_enable_review_coverage_footer

    assert review.startswith("original review")
    assert "⚠️ **Review coverage:**" in review
    assert "- `src/one.py`" in review
    assert "- `nested/two.md`" in review
    assert "\n\n<hr>\n\n" in review
    assert "\n\n---\n\n" not in review


def test_prepare_pr_review_hides_coverage_footer_when_disabled():
    reviewer = _make_prediction_reviewer()
    settings = get_settings()
    original_enable_review_coverage_footer = settings.pr_reviewer.enable_review_coverage_footer

    try:
        settings.pr_reviewer.enable_review_coverage_footer = False
        review = _render_review(reviewer, ["skipped.py"])
    finally:
        settings.pr_reviewer.enable_review_coverage_footer = original_enable_review_coverage_footer

    assert review == "original review"
    assert "Review coverage" not in review


def test_prepare_pr_review_places_coverage_footer_before_help_text():
    reviewer = _make_prediction_reviewer()
    settings = get_settings()
    original_enable_review_coverage_footer = settings.pr_reviewer.enable_review_coverage_footer
    original_enable_help_text = settings.pr_reviewer.enable_help_text

    try:
        settings.pr_reviewer.enable_review_coverage_footer = True
        settings.pr_reviewer.enable_help_text = True
        with patch("pr_agent.tools.pr_reviewer.HelpMessage.get_review_usage_guide", return_value="help text"):
            review = _render_review(reviewer, ["skipped.py"], supports_gfm_markdown=True)
    finally:
        settings.pr_reviewer.enable_review_coverage_footer = original_enable_review_coverage_footer
        settings.pr_reviewer.enable_help_text = original_enable_help_text

    assert review.index("⚠️ **Review coverage:**") < review.index("help text")


def test_prepare_pr_review_leaves_original_content_unchanged_without_remaining_files():
    reviewer = _make_prediction_reviewer()

    review = _render_review(reviewer, [])

    assert review == "original review"
    assert "Review coverage" not in review


def test_prepare_pr_review_warns_on_invalid_model_output_without_changing_markdown():
    reviewer = _make_prediction_reviewer()
    reviewer.prediction = "review:\n  key_issues_to_review: wrong"
    reviewer.git_provider.get_diff_files.return_value = []
    reviewer.git_provider.is_supported.return_value = False
    reviewer.set_review_labels = MagicMock()

    with (
        patch("pr_agent.tools.pr_reviewer.load_yaml", return_value={"review": {"key_issues_to_review": "wrong"}}),
        patch("pr_agent.tools.pr_reviewer.github_action_output"),
        patch("pr_agent.tools.pr_reviewer.convert_to_markdown_v2", return_value="original review"),
        patch("pr_agent.tools.pr_reviewer.get_logger") as get_logger,
    ):
        review = reviewer._prepare_pr_review()

    assert review == "original review"
    get_logger.return_value.warning.assert_called_once()
    warning = get_logger.return_value.warning.call_args.kwargs
    assert warning["artifact"] == {"field": "review.key_issues_to_review", "value": "wrong"}


def test_prepare_pr_review_does_not_warn_for_valid_model_output():
    reviewer = _make_prediction_reviewer()
    reviewer.prediction = "review:\n  key_issues_to_review: []"
    reviewer.git_provider.get_diff_files.return_value = []
    reviewer.git_provider.is_supported.return_value = False
    reviewer.set_review_labels = MagicMock()

    with (
        patch("pr_agent.tools.pr_reviewer.load_yaml", return_value={"review": {"key_issues_to_review": []}}),
        patch("pr_agent.tools.pr_reviewer.github_action_output"),
        patch("pr_agent.tools.pr_reviewer.convert_to_markdown_v2", return_value="original review"),
        patch("pr_agent.tools.pr_reviewer.get_logger") as get_logger,
    ):
        review = reviewer._prepare_pr_review()

    assert review == "original review"
    get_logger.return_value.warning.assert_not_called()


def test_review_schema_requires_enabled_prompt_fields_only():
    reviewer = _make_prediction_reviewer()
    reviewer.vars = {"require_tests": True}
    with patch("pr_agent.tools.pr_reviewer.get_logger") as get_logger:
        assert reviewer._validate_review_schema({"review": {"key_issues_to_review": []}}) is False

    warning = get_logger.return_value.warning.call_args.kwargs
    assert warning["artifact"] == {"field": "review.relevant_tests", "value": None}

    reviewer.vars = {"require_tests": False}
    get_logger.return_value.warning.reset_mock()
    assert reviewer._validate_review_schema({"review": {"key_issues_to_review": []}}) is True
    get_logger.return_value.warning.assert_not_called()


def test_review_schema_reports_none_for_missing_fields():
    reviewer = _make_prediction_reviewer()
    with patch("pr_agent.tools.pr_reviewer.get_logger") as get_logger:
        assert reviewer._validate_review_schema({"review": {}}) is False

    warning = get_logger.return_value.warning.call_args.kwargs
    assert warning["artifact"]["field"] == "review.key_issues_to_review"
    assert warning["artifact"]["value"] is None


def test_prepare_pr_review_limits_coverage_footer_to_50_files():
    reviewer = _make_prediction_reviewer()
    remaining_files = [f"file_{index}.py" for index in range(51)]

    review = _render_review(reviewer, remaining_files)

    assert review.count("- `file_") == 50
    assert "- `file_0.py`" in review
    assert "- `file_49.py`" in review
    assert "- `file_50.py`" not in review


def test_prepare_pr_review_reports_number_of_files_beyond_coverage_limit():
    reviewer = _make_prediction_reviewer()
    remaining_files = [f"file_{index}.py" for index in range(53)]

    review = _render_review(reviewer, remaining_files)

    assert "... and 3 more" in review
    assert "- `file_50.py`" not in review


def _key_issue(**overrides):
    issue = {
        "relevant_file": "app.py",
        "issue_header": "Possible Issue",
        "issue_content": "The new branch never releases the lock.",
        "start_line": 2,
        "end_line": 3,
    }
    issue.update(overrides)
    return issue


def _reviewer_with_findings(*issues, head_file="one\ntwo\nthree\nfour\n"):
    git_provider = AzureDevopsProvider.__new__(AzureDevopsProvider)
    git_provider.azure_devops_client = MagicMock()
    git_provider.azure_devops_client.get_threads.return_value = []
    git_provider.repo_slug = "repo"
    git_provider.workspace_slug = "project"
    git_provider.pr_num = 1
    git_provider.get_diff_files = MagicMock()
    git_provider.get_diff_files.return_value = [
        FilePatchInfo(base_file="", head_file=head_file, patch="", filename="app.py")
    ]
    git_provider.publish_code_suggestions = MagicMock(return_value=True)
    git_provider.max_comment_chars = None
    git_provider._inline_comment_store = None
    reviewer = _make_reviewer(git_provider)
    reviewer._published_inline_key_issue_fingerprints = MagicMock(
        side_effect=lambda _store, fingerprints: fingerprints
    )
    return reviewer, {"review": {"key_issues_to_review": list(issues)}}


def _published_comment(git_provider):
    published = git_provider.publish_code_suggestions.call_args_list[0].args[0]
    assert len(published) == 1
    return published[0]


def test_key_issues_are_published_on_their_lines_and_leave_the_summary():
    reviewer, data = _reviewer_with_findings(_key_issue())

    result = reviewer._publish_key_issues_as_inline_comments(data)

    comment = _published_comment(reviewer.git_provider)
    assert comment["relevant_file"] == "app.py"
    assert comment["relevant_lines_start"] == 2
    assert comment["relevant_lines_end"] == 3
    assert "The new branch never releases the lock." in comment["body"]
    assert "```suggestion" not in comment["body"]
    assert "key_issues_to_review" not in result["review"]
    assert len(data["review"]["key_issues_to_review"]) == 1


def test_github_key_issue_is_published_inline_and_removed_from_summary():
    provider = GithubProvider.__new__(GithubProvider)
    provider.pr = MagicMock()
    provider.pr.get_comments.return_value = []
    provider.last_commit_id = "head-sha"
    provider.max_comment_chars = 65000
    provider.get_diff_files = MagicMock(return_value=[
        FilePatchInfo(base_file="", head_file="one\ntwo\nthree\nfour\n", patch="", filename="app.py")
    ])
    provider.validate_comments_inside_hunks = lambda comments: comments
    reviewer = _make_reviewer(provider)
    data = {"review": {"key_issues_to_review": [_key_issue()]}}

    result = reviewer._publish_key_issues_as_inline_comments(data)

    posted = provider.pr.create_review.call_args.kwargs["comments"]
    assert len(posted) == 1
    assert posted[0]["path"] == "app.py"
    assert "The new branch never releases the lock." in posted[0]["body"]
    assert "key_issues_to_review" not in result["review"]


def test_prepare_pr_review_does_not_publish_key_issues_inline_by_default():
    reviewer = _make_prediction_reviewer()

    review = _render_review(reviewer, [])

    assert review == "original review"
    reviewer.git_provider.publish_code_suggestions.assert_not_called()


def test_prepare_pr_review_publishes_key_issues_inline_when_enabled():
    reviewer = _make_prediction_reviewer()
    settings = get_settings()
    original_inline_key_issues = settings.pr_reviewer.get("inline_key_issues", False)
    reviewer._publish_key_issues_as_inline_comments = MagicMock(return_value={"review": {}})

    try:
        settings.pr_reviewer.inline_key_issues = True
        _render_review(reviewer, [])
    finally:
        settings.pr_reviewer.inline_key_issues = original_inline_key_issues

    reviewer._publish_key_issues_as_inline_comments.assert_called_once()


@pytest.mark.parametrize("issue", [
    _key_issue(relevant_file="not_in_the_diff.py"),
    _key_issue(start_line=0, end_line=0),
    _key_issue(start_line=3, end_line=2),
    _key_issue(start_line=40, end_line=41),
    _key_issue(issue_content=""),
])
def test_unanchorable_key_issue_stays_in_the_summary(issue):
    reviewer, data = _reviewer_with_findings(issue)

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert result["review"]["key_issues_to_review"] == [issue]


def test_key_issue_that_fails_to_publish_stays_in_the_summary():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    reviewer.git_provider.publish_code_suggestions.return_value = False
    reviewer._published_inline_key_issue_fingerprints.side_effect = None
    reviewer._published_inline_key_issue_fingerprints.return_value = set()

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert result["review"]["key_issues_to_review"] == [issue]


def test_key_issue_that_cannot_be_verified_stays_in_the_summary():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    reviewer._published_inline_key_issue_fingerprints.side_effect = None
    reviewer._published_inline_key_issue_fingerprints.return_value = set()

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert result["review"]["key_issues_to_review"] == [issue]


def test_key_issue_without_file_content_stays_in_the_summary():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue, head_file="")

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert result["review"]["key_issues_to_review"] == [issue]


def test_key_issue_is_not_published_when_the_provider_cannot_verify_it():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    reviewer._can_verify_inline_key_issue_publication = MagicMock(return_value=False)

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert result is data


def test_gitlab_can_verify_inline_key_issue_publication():
    provider = GitLabProvider.__new__(GitLabProvider)
    provider.mr = MagicMock()
    provider.mr.discussions.list.return_value = []
    provider.mr.notes.list.return_value = []
    provider.mr.draft_notes.list.return_value = []

    reviewer = _make_reviewer(provider)

    assert reviewer._can_verify_inline_key_issue_publication() is True


def test_same_key_issue_on_different_lines_is_published_at_each_location():
    first = _key_issue(start_line=1, end_line=1)
    second = _key_issue(start_line=3, end_line=3)
    reviewer, data = _reviewer_with_findings(first, second)

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert reviewer.git_provider.publish_code_suggestions.call_count == 1
    assert len(reviewer.git_provider.publish_code_suggestions.call_args.args[0]) == 2
    assert "key_issues_to_review" not in result["review"]


def test_duplicate_key_issue_is_published_once():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue, issue.copy())

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert len(reviewer.git_provider.publish_code_suggestions.call_args.args[0]) == 1
    assert "key_issues_to_review" not in result["review"]


def test_key_issues_that_diverge_after_eighty_characters_are_both_published():
    prefix = "x" * 100
    first = _key_issue(issue_content=f"{prefix}a")
    second = _key_issue(issue_content=f"{prefix}b")
    reviewer, data = _reviewer_with_findings(first, second)

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert len(reviewer.git_provider.publish_code_suggestions.call_args.args[0]) == 2
    assert "key_issues_to_review" not in result["review"]


def test_unverified_duplicate_key_issue_stays_in_the_summary():
    issue = _key_issue()
    duplicate = issue.copy()
    reviewer, data = _reviewer_with_findings(issue, duplicate)
    reviewer._published_inline_key_issue_fingerprints.side_effect = None
    reviewer._published_inline_key_issue_fingerprints.return_value = set()

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert result is data
    assert result["review"]["key_issues_to_review"] == [issue, duplicate]


def test_batch_publish_failure_keeps_unverified_findings_in_the_summary():
    failing = _key_issue(issue_content="This one raises.")
    working = _key_issue(issue_content="This one publishes.", start_line=1, end_line=1)
    reviewer, data = _reviewer_with_findings(failing, working)
    reviewer.git_provider.publish_code_suggestions.side_effect = RuntimeError("API rejected the comments")
    reviewer._published_inline_key_issue_fingerprints.side_effect = None
    reviewer._published_inline_key_issue_fingerprints.return_value = set()

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert reviewer.git_provider.publish_code_suggestions.call_count == 1
    assert result["review"]["key_issues_to_review"] == [failing, working]


def test_existing_comment_load_failure_skips_inline_publishing():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    reviewer.git_provider.azure_devops_client.get_threads.side_effect = RuntimeError("request failed")

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert result is data


def test_publish_without_a_success_record_keeps_findings_in_the_summary():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    reviewer.git_provider.azure_devops_client.get_threads.return_value = []
    reviewer._published_inline_key_issue_fingerprints = (
        PRReviewer._published_inline_key_issue_fingerprints.__get__(reviewer)
    )

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert result["review"]["key_issues_to_review"] == [issue]


def test_existing_azure_thread_removes_finding_from_summary():
    reviewer, data = _reviewer_with_findings(_key_issue())
    body = "**Possible Issue**\n\nThe new branch never releases the lock."
    fingerprint = key_issue_fingerprint("app.py", body)
    reviewer.git_provider.azure_devops_client.get_threads.return_value = [
        SimpleNamespace(
            thread_context=SimpleNamespace(
                file_path="app.py",
                right_file_start=SimpleNamespace(line=2),
            ),
            comments=[SimpleNamespace(content=body_with_markers(body, fingerprint, None))],
        )
    ]

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert "key_issues_to_review" not in result["review"]


def test_recent_azure_post_is_verified_before_thread_listing_catches_up():
    reviewer, data = _reviewer_with_findings(_key_issue())
    reviewer.git_provider.publish_code_suggestions = (
        AzureDevopsProvider.publish_code_suggestions.__get__(reviewer.git_provider)
    )
    reviewer._published_inline_key_issue_fingerprints = (
        PRReviewer._published_inline_key_issue_fingerprints.__get__(reviewer)
    )

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert reviewer.git_provider.azure_devops_client.create_thread.call_count == 1
    assert "key_issues_to_review" not in result["review"]


def test_recent_azure_post_does_not_reload_threads_for_verification():
    reviewer, data = _reviewer_with_findings(_key_issue())
    reviewer.git_provider.publish_code_suggestions = (
        AzureDevopsProvider.publish_code_suggestions.__get__(reviewer.git_provider)
    )
    reviewer._published_inline_key_issue_fingerprints = (
        PRReviewer._published_inline_key_issue_fingerprints.__get__(reviewer)
    )

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert reviewer.git_provider.azure_devops_client.get_threads.call_count == 1
    assert "key_issues_to_review" not in result["review"]


def test_same_finding_at_failed_location_stays_in_the_summary():
    published = _key_issue(start_line=1, end_line=1)
    failed = _key_issue(start_line=3, end_line=3)
    reviewer, data = _reviewer_with_findings(published, failed)
    reviewer.git_provider.publish_code_suggestions = (
        AzureDevopsProvider.publish_code_suggestions.__get__(reviewer.git_provider)
    )
    reviewer.git_provider.azure_devops_client.create_thread.side_effect = [MagicMock(), RuntimeError("failed")]
    reviewer._published_inline_key_issue_fingerprints = (
        PRReviewer._published_inline_key_issue_fingerprints.__get__(reviewer)
    )

    result = reviewer._publish_key_issues_as_inline_comments(data)

    assert reviewer.git_provider.azure_devops_client.create_thread.call_count == 2
    assert result["review"]["key_issues_to_review"] == [failed]


def test_key_issue_already_anchored_on_the_pr_is_not_published_again():
    issue = _key_issue()
    reviewer, data = _reviewer_with_findings(issue)
    store = get_inline_comment_store(reviewer.git_provider)
    store.add(key_issue_fingerprint(
        "app.py", "**Possible Issue**\n\nThe new branch never releases the lock."
    ))

    result = reviewer._publish_key_issues_as_inline_comments(data)

    reviewer.git_provider.publish_code_suggestions.assert_not_called()
    assert "key_issues_to_review" not in result["review"]


def test_key_issue_path_without_leading_slash_uses_azure_diff_path():
    reviewer, data = _reviewer_with_findings(_key_issue())
    reviewer.git_provider.get_diff_files.return_value[0].filename = "/app.py"

    reviewer._publish_key_issues_as_inline_comments(data)

    assert _published_comment(reviewer.git_provider)["relevant_file"] == "/app.py"


def test_key_issue_suggestion_fence_is_published_as_plain_code():
    issue = _key_issue(issue_content="Use this code:\n```suggestion\nlock.release()\n```")
    reviewer, data = _reviewer_with_findings(issue)

    reviewer._publish_key_issues_as_inline_comments(data)

    body = _published_comment(reviewer.git_provider)["body"]
    assert "```suggestion" not in body
    assert "```text" in body


def test_should_publish_review_no_suggestions_respects_config():
    reviewer = _make_reviewer()
    settings = get_settings()
    original_publish_no_suggestions = settings.pr_reviewer.publish_output_no_suggestions

    try:
        settings.pr_reviewer.publish_output_no_suggestions = False
        assert reviewer._should_publish_review_no_suggestions("No major issues detected") is False
        assert reviewer._should_publish_review_no_suggestions("A major issue was detected") is True

        settings.pr_reviewer.publish_output_no_suggestions = True
        assert reviewer._should_publish_review_no_suggestions("No major issues detected") is True
    finally:
        settings.pr_reviewer.publish_output_no_suggestions = original_publish_no_suggestions


@pytest.mark.asyncio
async def test_run_removes_its_progress_comment_when_quiet_output_suppresses_review(monkeypatch):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.return_value = progress_comment
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None
    reviewer._prepare_pr_review = lambda: "No major issues detected"

    async def fake_retry(prepare_fn, model_type=None, git_provider=None):
        reviewer.prediction = "prediction"

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(pr_reviewer_module, "retry_with_fallback_models", fake_retry)

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "publish_output_no_suggestions": settings.pr_reviewer.publish_output_no_suggestions,
        "is_auto_command": settings.config.get("is_auto_command", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.pr_reviewer.publish_output_no_suggestions = False

        await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.pr_reviewer.publish_output_no_suggestions = original["publish_output_no_suggestions"]

    git_provider.publish_comment.assert_called_once_with("Preparing review...", is_temporary=True)
    git_provider.remove_comment.assert_called_once_with(progress_comment)
    git_provider.remove_initial_comment.assert_not_called()
    git_provider.publish_persistent_comment.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize("propagate_tool_errors", [False, True])
async def test_run_removes_its_progress_comment_when_review_generation_fails(
        monkeypatch, propagate_tool_errors):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.return_value = progress_comment
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    review_error = RuntimeError("model unavailable")
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=review_error),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = propagate_tool_errors

        if propagate_tool_errors:
            with pytest.raises(RuntimeError, match="model unavailable") as exc_info:
                await reviewer.run()
            assert exc_info.value is review_error
        else:
            await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        (("Failed to review PR",), {}),
    ]
    git_provider.remove_comment.assert_called_once_with(progress_comment)
    git_provider.remove_initial_comment.assert_not_called()


@pytest.mark.asyncio
async def test_run_publishes_sanitized_failure_reason_when_enabled(monkeypatch):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.return_value = progress_comment
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    provider_error = RuntimeError("Your credit balance is too low; token=sk-ant-secret")
    review_error = RuntimeError("Failed to generate prediction with any model")
    review_error.__cause__ = provider_error
    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=review_error),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
        "publish_error_details": settings.pr_reviewer.get("publish_error_details", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = False
        settings.pr_reviewer.publish_error_details = True

        await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]
        settings.pr_reviewer.publish_error_details = original["publish_error_details"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        ((
            "Failed to review PR\n\n"
            "**Reason:** The model provider rejected the request because the API account has insufficient credits. "
            "Add credits, then retry the command.",
        ), {}),
    ]
    git_provider.remove_comment.assert_called_once_with(progress_comment)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("prediction", "expected_action_data"),
    [
        ("::: not : valid : yaml :::\n\t- [", {}),
        ("review: {}", {"review": {}}),
        ("review: [invalid]", {"review": ["invalid"]}),
    ],
    ids=["unparseable", "empty-review", "invalid-review-shape"],
)
@pytest.mark.parametrize("persistent_comment", [False, True])
@pytest.mark.parametrize("propagate_tool_errors", [False, True])
async def test_run_does_not_publish_an_empty_review(
    monkeypatch,
    prediction,
    expected_action_data,
    persistent_comment,
    propagate_tool_errors,
):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.return_value = progress_comment
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None
    reviewer.prediction_data = None

    async def fake_retry(prepare_fn, model_type=None, git_provider=None):
        reviewer.prediction = prediction

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(pr_reviewer_module, "retry_with_fallback_models", fake_retry)
    action_output = MagicMock()
    push_output = MagicMock()
    monkeypatch.setattr(pr_reviewer_module, "github_action_output", action_output)
    monkeypatch.setattr(pr_reviewer_module, "push_outputs", push_output)

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
        "persistent_comment": settings.pr_reviewer.persistent_comment,
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = propagate_tool_errors
        settings.pr_reviewer.persistent_comment = persistent_comment

        if propagate_tool_errors:
            with pytest.raises(ValueError, match="Failed to prepare review output"):
                await reviewer.run()
        else:
            await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]
        settings.pr_reviewer.persistent_comment = original["persistent_comment"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        (("Failed to review PR",), {}),
    ]
    git_provider.publish_persistent_comment.assert_not_called()
    git_provider.publish_structured_review.assert_not_called()
    action_output.assert_called_once_with(expected_action_data, "review")
    push_output.assert_not_called()
    git_provider.remove_comment.assert_called_once_with(progress_comment)


@pytest.mark.asyncio
async def test_run_publishes_failure_result_when_progress_comment_has_no_handle(monkeypatch):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.side_effect = [None, MagicMock()]
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=RuntimeError("model unavailable")),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = False

        await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        (("Failed to review PR",), {}),
    ]
    git_provider.remove_comment.assert_not_called()
    git_provider.remove_initial_comment.assert_not_called()


@pytest.mark.asyncio
async def test_run_publishes_failure_result_when_review_fails_before_progress_comment():
    review_error = RuntimeError("files unavailable")
    git_provider = MagicMock()
    git_provider.get_files.side_effect = review_error
    reviewer = _make_reviewer(git_provider)

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = False

        await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    git_provider.publish_comment.assert_called_once_with("Failed to review PR")
    git_provider.remove_comment.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("publish_output", "is_auto_command", "propagate_tool_errors"),
    [
        (False, False, False),
        (False, False, True),
        (True, True, False),
        (True, True, True),
    ],
)
async def test_run_does_not_publish_failure_result_when_output_disabled_or_auto(
        monkeypatch, publish_output, is_auto_command, propagate_tool_errors):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    review_error = RuntimeError("model unavailable")
    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=review_error),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = publish_output
        settings.config.is_auto_command = is_auto_command
        settings.config.propagate_tool_errors = propagate_tool_errors

        if propagate_tool_errors:
            with pytest.raises(RuntimeError, match="model unavailable") as exc_info:
                await reviewer.run()
            assert exc_info.value is review_error
        else:
            await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    git_provider.publish_comment.assert_not_called()
    git_provider.remove_comment.assert_not_called()
    git_provider.remove_initial_comment.assert_not_called()


@pytest.mark.asyncio
async def test_run_publishes_failure_result_when_progress_cleanup_fails(monkeypatch):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.return_value = progress_comment
    git_provider.remove_comment.side_effect = RuntimeError("cleanup failed")
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    review_error = RuntimeError("model unavailable")
    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=review_error),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = True

        with pytest.raises(RuntimeError, match="model unavailable") as exc_info:
            await reviewer.run()
        assert exc_info.value is review_error
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        (("Failed to review PR",), {}),
    ]
    git_provider.remove_comment.assert_called_once_with(progress_comment)


@pytest.mark.asyncio
@pytest.mark.parametrize("propagate_tool_errors", [False, True])
async def test_run_failure_result_publication_does_not_mask_review_error(
        monkeypatch, propagate_tool_errors):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    publication_error = RuntimeError("comment unavailable")
    git_provider = MagicMock()
    git_provider.get_files.return_value = ["app.py"]
    git_provider.publish_comment.side_effect = [progress_comment, publication_error]
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None

    review_error = RuntimeError("model unavailable")
    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", AsyncMock())
    monkeypatch.setattr(
        pr_reviewer_module,
        "retry_with_fallback_models",
        AsyncMock(side_effect=review_error),
    )

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "is_auto_command": settings.config.get("is_auto_command", False),
        "propagate_tool_errors": settings.config.get("propagate_tool_errors", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.config.propagate_tool_errors = propagate_tool_errors

        if propagate_tool_errors:
            with pytest.raises(RuntimeError, match="model unavailable") as exc_info:
                await reviewer.run()
            assert exc_info.value is review_error
        else:
            await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.config.propagate_tool_errors = original["propagate_tool_errors"]

    assert git_provider.publish_comment.call_args_list == [
        (("Preparing review...",), {"is_temporary": True}),
        (("Failed to review PR",), {}),
    ]
    git_provider.remove_comment.assert_called_once_with(progress_comment)


def test_prepare_review_publishes_provider_neutral_structured_data(monkeypatch):
    git_provider = MagicMock()
    git_provider.is_supported.return_value = False
    git_provider.get_diff_files.return_value = []
    reviewer = _make_prediction_reviewer(git_provider)
    reviewer.prediction = """review:
  key_issues_to_review: []
  security_concerns: no
"""
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.set_review_labels = MagicMock()
    monkeypatch.setattr(
        "pr_agent.tools.pr_reviewer.convert_to_markdown_v2",
        lambda *args, **kwargs: "## Review",
    )

    from pr_agent.algo.run_details import add_token_usage, init_run_details

    init_run_details()
    add_token_usage({"prompt_tokens": 30, "completion_tokens": 12, "total_tokens": 42})

    reviewer._prepare_pr_review()

    git_provider.publish_structured_review.assert_called_once_with({
        "review": {
            "key_issues_to_review": [],
            "security_concerns": False,
        },
        "usage": {"prompt_tokens": 30, "completion_tokens": 12, "total_tokens": 42},
    })
    # Assert key order to prove the snapshot is isolated: _prepare_pr_review moves
    # key_issues_to_review to the end of its own dict after the hook fires, so an
    # aliased snapshot ends with it while a deep copy keeps the original order.
    # (assert_called_once_with cannot catch this: dict equality ignores key order.)
    published = git_provider.publish_structured_review.call_args[0][0]
    assert list(published["review"].keys()) == ["key_issues_to_review", "security_concerns"]


def test_can_run_incremental_review_skips_auto_mode_without_new_commit():
    reviewer = _make_reviewer()
    reviewer.is_auto = True
    reviewer.incremental = SimpleNamespace(first_new_commit_sha=None)

    assert reviewer._can_run_incremental_review() is False


@pytest.fixture
def review_label_settings():
    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "require_estimate_effort_to_review": settings.pr_reviewer.require_estimate_effort_to_review,
        "require_security_review": settings.pr_reviewer.require_security_review,
        "enable_review_labels_effort": settings.pr_reviewer.enable_review_labels_effort,
        "enable_review_labels_security": settings.pr_reviewer.enable_review_labels_security,
    }
    settings.config.publish_output = True
    settings.pr_reviewer.require_estimate_effort_to_review = True
    settings.pr_reviewer.require_security_review = True
    settings.pr_reviewer.enable_review_labels_effort = True
    settings.pr_reviewer.enable_review_labels_security = True
    yield
    settings.config.publish_output = original["publish_output"]
    settings.pr_reviewer.require_estimate_effort_to_review = original["require_estimate_effort_to_review"]
    settings.pr_reviewer.require_security_review = original["require_security_review"]
    settings.pr_reviewer.enable_review_labels_effort = original["enable_review_labels_effort"]
    settings.pr_reviewer.enable_review_labels_security = original["enable_review_labels_security"]


def test_set_review_labels_replaces_stale_review_labels_and_keeps_user_labels(review_label_settings):
    git_provider = MagicMock()
    git_provider.get_pr_labels.return_value = ["Review effort 1/5", "Possible security concern", "keep-me"]
    reviewer = _make_reviewer(git_provider)
    data = {
        "review": {
            "estimated_effort_to_review_[1-5]": "3, moderate",
            "security_concerns": "SQL injection: the order id is concatenated into the query\n",
        }
    }

    reviewer.set_review_labels(data)

    git_provider.publish_labels.assert_called_once_with([
        "Review effort 3/5",
        "Possible security concern",
        "keep-me",
    ])


@pytest.mark.parametrize(
    "security_concerns, expect_label",
    [
        ("SQL injection: the order id is concatenated into the query\n", True),
        ("Sensitive information exposure: the API key is written to the log\n", True),
        ("No\n", False),
        ("no", False),
        ("  No  \n", False),
        ("", False),
        (None, False),
        # A punctuated negative is not a recognised "no", so it labels and renders as a concern.
        ("No.", True),
    ],
)
def test_set_review_labels_security_label_matches_the_rendered_review_body(
    review_label_settings, security_concerns, expect_label
):
    git_provider = MagicMock()
    git_provider.get_pr_labels.return_value = []
    reviewer = _make_reviewer(git_provider)
    data = {"review": {"estimated_effort_to_review_[1-5]": "2", "security_concerns": security_concerns}}

    reviewer.set_review_labels(data)

    published = git_provider.publish_labels.call_args[0][0]
    assert ("Possible security concern" in published) is expect_label

    body = convert_to_markdown_v2(data)
    assert ("<strong>Security concerns</strong>" in body) is expect_label


@pytest.mark.parametrize("missing_value", [None, ""])
def test_set_review_labels_keeps_existing_security_label_when_verdict_is_missing(
    review_label_settings, missing_value
):
    # A truncated model response leaves security_concerns missing (None), which
    # is not a valid negative verdict, so an already published security alert
    # label must be preserved instead of being filtered out. An empty string is
    # a recognised negative and does clear the stale label, matching the body.
    git_provider = MagicMock()
    git_provider.get_pr_labels.return_value = ["Possible security concern", "keep-me"]
    reviewer = _make_reviewer(git_provider)
    data = {"review": {"estimated_effort_to_review_[1-5]": "2", "security_concerns": missing_value}}

    reviewer.set_review_labels(data)

    published = git_provider.publish_labels.call_args[0][0]
    if missing_value is None:
        assert "Possible security concern" in published
    else:
        assert "Possible security concern" not in published
    assert "keep-me" in published


def test_set_review_labels_does_not_label_security_free_localized_review(review_label_settings):
    # With a non-English response language the model is told to keep the exact
    # English 'No' sentinel, so a security-free review must not get the label.
    settings = get_settings()
    original_language = settings.config.response_language
    settings.config.response_language = "de-DE"
    try:
        git_provider = MagicMock()
        git_provider.get_pr_labels.return_value = []
        reviewer = _make_reviewer(git_provider)
        data = {"review": {"estimated_effort_to_review_[1-5]": "2", "security_concerns": "No"}}

        reviewer.set_review_labels(data)

        published = git_provider.publish_labels.call_args[0][0]
        assert "Possible security concern" not in published
    finally:
        settings.config.response_language = original_language


def test_security_concerns_field_prompt_preserves_no_sentinel_for_localized_responses():
    # The prompt must keep the exact English 'No' sentinel even when the
    # response language instructs the model to localize its answer, otherwise
    # localized negatives are treated as security concerns by the label and the
    # rendered body.
    prompt = get_settings().pr_review_prompt.system
    security_field = prompt.split("security_concerns: str = Field(description=")[1].split("\n")[0]
    assert "Answer 'No'" in security_field
    assert "do not translate it into another language" in security_field


def test_set_review_labels_skips_providers_without_label_support(review_label_settings):
    git_provider = MagicMock()
    git_provider.is_supported.return_value = False
    reviewer = _make_reviewer(git_provider)
    data = {
        "review": {
            "estimated_effort_to_review_[1-5]": "3, moderate",
            "security_concerns": "SQL injection: the order id is concatenated into the query\n",
        }
    }

    reviewer.set_review_labels(data)

    git_provider.get_pr_labels.assert_not_called()
    git_provider.publish_labels.assert_not_called()


def test_get_user_answers_collects_question_and_answer_from_issue_comments():
    git_provider = MagicMock()
    git_provider.get_issue_comments.return_value = [
        SimpleNamespace(body="Unrelated"),
        SimpleNamespace(body="Questions to better understand the PR:\n- Why?"),
        SimpleNamespace(body="/answer Because it fixes production."),
    ]
    reviewer = _make_reviewer(git_provider)
    reviewer.is_answer = True

    question, answer = reviewer._get_user_answers()

    assert question == "Questions to better understand the PR:\n- Why?"
    assert answer == "/answer Because it fixes production."


@pytest.mark.asyncio
@pytest.mark.parametrize("persistent", [True, False])
@pytest.mark.parametrize("thread_enabled", [True, False])
async def test_run_threads_only_the_final_review_comment(monkeypatch, persistent, thread_enabled):
    """`as_thread` is forwarded to the review's final publish call only when the provider opts in
    (should_publish_review_as_thread), and is omitted entirely otherwise - other providers'
    publish methods don't accept it. Status/progress comments are never threaded.
    """
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.should_publish_review_as_thread.return_value = thread_enabled
    git_provider.supports_review_finding_state.return_value = True
    git_provider.is_supported.return_value = True
    git_provider.supports_review_comment_identity.return_value = False
    git_provider.publish_comment.return_value = progress_comment
    git_provider.publish_persistent_comment_full.return_value = object()
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=False)
    reviewer.vars = {}
    reviewer.prediction = None
    review_text = "## PR Reviewer Guide 🔍\n\nsome findings"
    reviewer._prepare_pr_review = lambda: review_text

    async def fake_extract_tickets(git_provider, vars):
        return None

    async def fake_retry(prepare_fn, model_type=None, git_provider=None):
        reviewer.prediction = "prediction"

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", fake_extract_tickets)
    monkeypatch.setattr(pr_reviewer_module, "retry_with_fallback_models", fake_retry)

    settings = get_settings()
    original = {
        "publish_output": settings.config.publish_output,
        "persistent_comment": settings.pr_reviewer.persistent_comment,
        "is_auto_command": settings.config.get("is_auto_command", False),
    }
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.pr_reviewer.persistent_comment = persistent

        await reviewer.run()
    finally:
        settings.config.publish_output = original["publish_output"]
        settings.config.is_auto_command = original["is_auto_command"]
        settings.pr_reviewer.persistent_comment = original["persistent_comment"]

    if persistent:
        publish = git_provider.publish_persistent_comment_full
        publish.assert_called_once()
        assert publish.call_args.kwargs["require_agent_authorship"] is True
        assert publish.call_args.kwargs["fallback_on_error"] is False
        git_provider.publish_persistent_comment.assert_not_called()
        assert publish.call_args.kwargs["identity_marker"] == PRReviewIdentity.REGULAR.value
        assert publish.call_args.kwargs["legacy_initial_header"] == f"{PRReviewHeader.REGULAR.value} 🔍"
    else:
        publish = git_provider.publish_comment
    assert publish.call_args.args[0] == review_text
    if thread_enabled:
        assert publish.call_args.kwargs.get("as_thread") is True
    else:
        assert "as_thread" not in publish.call_args.kwargs
    # The temporary progress comment is published without as_thread regardless of the flag.
    git_provider.publish_comment.assert_any_call("Preparing review...", is_temporary=True)
    git_provider.remove_comment.assert_called_once_with(progress_comment)
    git_provider.remove_initial_comment.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("is_incremental", "expected_identity"),
    [
        (False, PRReviewIdentity.REGULAR.value),
        (True, PRReviewIdentity.INCREMENTAL.value),
    ],
)
async def test_nonpersistent_review_adds_identity_for_incremental_capable_provider(
    monkeypatch,
    is_incremental,
    expected_identity,
):
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    progress_comment = MagicMock()
    git_provider = MagicMock()
    git_provider.should_publish_review_as_thread.return_value = False
    git_provider.supports_review_comment_identity.return_value = True
    git_provider.publish_comment.return_value = progress_comment
    reviewer = _make_reviewer(git_provider)
    reviewer.incremental = SimpleNamespace(is_incremental=is_incremental)
    if is_incremental:
        reviewer._can_run_incremental_review = lambda: True
    reviewer.vars = {}
    reviewer.prediction = None
    reviewer._prepare_pr_review = lambda: "## Team Review 🔍\n\nsome findings"

    async def fake_extract_tickets(git_provider, vars):
        return None

    async def fake_retry(prepare_fn, model_type=None, git_provider=None):
        reviewer.prediction = "prediction"

    monkeypatch.setattr(pr_reviewer_module, "extract_and_cache_pr_tickets", fake_extract_tickets)
    monkeypatch.setattr(pr_reviewer_module, "retry_with_fallback_models", fake_retry)

    settings = get_settings()
    original_publish_output = settings.config.publish_output
    original_persistent_comment = settings.pr_reviewer.persistent_comment
    original_auto_command = settings.config.get("is_auto_command", False)
    try:
        settings.config.publish_output = True
        settings.config.is_auto_command = False
        settings.pr_reviewer.persistent_comment = False

        await reviewer.run()
    finally:
        settings.config.publish_output = original_publish_output
        settings.config.is_auto_command = original_auto_command
        settings.pr_reviewer.persistent_comment = original_persistent_comment

    published_review = [
        call
        for call in git_provider.publish_comment.call_args_list
        if call.args and call.args[0].startswith("## Team Review")
    ]
    assert len(published_review) == 1
    assert expected_identity in published_review[0].args[0]


def test_init_maps_user_question_and_answer_to_correct_prompt_vars(monkeypatch):
    """Behavioral regression for the swapped-unpacking bug (#2496).

    The bug lived in ``PRReviewer.__init__``: ``_get_user_answers()`` returns
    ``(question, answer)`` but the tuple was unpacked as ``answer, question``,
    so the review prompt rendered the user's answer under ``{{ question_str }}``
    and the question under ``{{ answer_str }}``. This drives the real ``__init__``
    (external collaborators stubbed) and asserts each value lands in ``self.vars``
    under the correct key — so it fails if the unpack is ever swapped again,
    regardless of how the line is formatted.
    """
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    provider = MagicMock()
    provider.is_supported.return_value = True
    provider.get_languages.return_value = {}
    provider.get_files.return_value = []
    provider.get_issue_comments.return_value = [
        SimpleNamespace(body="Questions to better understand the PR:\n- Why?"),
        SimpleNamespace(body="/answer Because it fixes production."),
    ]
    provider.get_pr_description.return_value = ("desc", [])

    monkeypatch.setattr(pr_reviewer_module, "get_git_provider_with_context", lambda pr_url: provider)
    monkeypatch.setattr(pr_reviewer_module, "get_main_pr_language", lambda languages, files: "Python")
    monkeypatch.setattr(pr_reviewer_module, "TokenHandler", MagicMock())

    reviewer = PRReviewer(
        "https://example/pr/1",
        is_answer=True,
        ai_handler=lambda: SimpleNamespace(main_pr_language=None),
    )

    assert reviewer.vars["question_str"] == "Questions to better understand the PR:\n- Why?"
    assert reviewer.vars["answer_str"] == "/answer Because it fixes production."


def _build_answer_mode_reviewer(monkeypatch, issue_comments):
    """Drive the real ``PRReviewer.__init__`` in answer mode over ``issue_comments``."""
    from pr_agent.tools import pr_reviewer as pr_reviewer_module

    provider = MagicMock()
    provider.is_supported.return_value = True
    provider.get_languages.return_value = {}
    provider.get_files.return_value = []
    provider.get_issue_comments.return_value = issue_comments
    provider.get_pr_description.return_value = ("desc", [])

    monkeypatch.setattr(pr_reviewer_module, "get_git_provider_with_context", lambda pr_url: provider)
    monkeypatch.setattr(pr_reviewer_module, "get_main_pr_language", lambda languages, files: "Python")
    monkeypatch.setattr(pr_reviewer_module, "TokenHandler", MagicMock())

    return PRReviewer(
        "https://example/pr/1",
        is_answer=True,
        ai_handler=lambda: SimpleNamespace(main_pr_language=None),
    )


def test_answer_mode_reads_comments_from_a_non_list_iterable(monkeypatch):
    """GitHub hands back a PyGithub ``PaginatedList``, GitLab a plain list.

    Answer mode used to reach for the PyGithub-only ``.reversed`` property, which meant
    it could only ever consume the GitHub shape. Any lazily-paginated iterable must work.
    """

    class _Paginated:
        def __init__(self, items):
            self._items = items

        def __iter__(self):
            return iter(self._items)

    reviewer = _build_answer_mode_reviewer(monkeypatch, _Paginated([
        SimpleNamespace(body="Questions to better understand the PR:\n- Why?"),
        SimpleNamespace(body="/answer Because it fixes production."),
    ]))

    assert reviewer.vars["question_str"] == "Questions to better understand the PR:\n- Why?"
    assert reviewer.vars["answer_str"] == "/answer Because it fixes production."


def test_answer_mode_uses_the_lazy_reversed_view_when_the_provider_offers_one(monkeypatch):
    """PyGithub reverses a PaginatedList lazily, walking pages from the end.

    Materialising it instead would page the whole thread just to read the last exchange,
    so the lazy view must win when it exists.
    """

    class _LazyPaginated:
        def __init__(self, items):
            self._items = items

        @property
        def reversed(self):
            return list(reversed(self._items))

        def __iter__(self):
            raise AssertionError("the lazy reversed view should have been used")

    reviewer = _build_answer_mode_reviewer(monkeypatch, _LazyPaginated([
        SimpleNamespace(body="Questions to better understand the PR:\n- Why?"),
        SimpleNamespace(body="/answer Because it fixes production."),
    ]))

    assert reviewer.vars["question_str"] == "Questions to better understand the PR:\n- Why?"
    assert reviewer.vars["answer_str"] == "/answer Because it fixes production."


def test_answer_mode_prefers_the_newest_question_and_answer(monkeypatch):
    """Comments arrive oldest-first, so the walk must run newest-first to pick the latest exchange."""
    reviewer = _build_answer_mode_reviewer(monkeypatch, [
        SimpleNamespace(body="Questions to better understand the PR:\n- Stale question?"),
        SimpleNamespace(body="/answer Stale answer."),
        SimpleNamespace(body="Questions to better understand the PR:\n- Current question?"),
        SimpleNamespace(body="/answer Current answer."),
    ])

    assert reviewer.vars["question_str"] == "Questions to better understand the PR:\n- Current question?"
    assert reviewer.vars["answer_str"] == "/answer Current answer."


def _render_review_capturing_push(reviewer, publish_output):
    reviewer.prediction = "review: {}"
    reviewer.remaining_files_list = []
    reviewer.git_provider.get_diff_files.return_value = []
    reviewer.git_provider.is_supported.return_value = False
    reviewer.set_review_labels = MagicMock()

    settings = get_settings()
    original_publish_output = settings.config.publish_output
    try:
        settings.config.publish_output = publish_output
        with (
            patch("pr_agent.tools.pr_reviewer.load_yaml", return_value={"review": {"score": "1"}}),
            patch("pr_agent.tools.pr_reviewer.github_action_output"),
            patch("pr_agent.tools.pr_reviewer.convert_to_markdown_v2", return_value="original review"),
            patch("pr_agent.tools.pr_reviewer.push_outputs") as push,
        ):
            reviewer._prepare_pr_review()
        return push
    finally:
        settings.config.publish_output = original_publish_output


def test_prepare_pr_review_does_not_push_outputs_on_a_dry_run():
    # publish_output=false is used by the CLI and by mosaico's dispatch to render a review
    # without touching the PR; it must not reach an external sink either.
    push = _render_review_capturing_push(_make_prediction_reviewer(), publish_output=False)
    push.assert_not_called()


def test_prepare_pr_review_pushes_outputs_when_publishing():
    push = _render_review_capturing_push(_make_prediction_reviewer(), publish_output=True)
    push.assert_called_once()
    assert push.call_args.args[0] == "review"
    assert push.call_args.kwargs["payload"] == {"score": "1"}
    assert push.call_args.kwargs["markdown"] == "original review"
