import copy
import json
from io import BytesIO
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
from giteapy.rest import ApiException
from starlette_context import context, request_cycle_context

from pr_agent.config_loader import global_settings
from pr_agent.git_providers.git_provider import GitProvider
from pr_agent.git_providers.gitea_provider import GiteaProvider


def test_gitea_comment_url_accepts_dict_fields():
    provider = GiteaProvider.__new__(GiteaProvider)

    html_url_comment = {"html_url": "https://gitea.example/comment/1"}
    assert provider.get_comment_url(html_url_comment) == (
        "https://gitea.example/comment/1"
    )
    url_comment = {"url": "https://gitea.example/comment/2"}
    assert provider.get_comment_url(url_comment) == (
        "https://gitea.example/comment/2"
    )


@pytest.mark.parametrize(
    ("comment", "expected_id"),
    [
        ({"comment_id": 7, "id": 42}, 7),
        ({"id": 42}, 42),
    ],
)
def test_gitea_edit_comment_accepts_dict_ids(comment, expected_id):
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.repo_api = MagicMock()
    provider.owner = "owner"
    provider.repo = "repo"
    provider.max_comment_chars = 1000

    provider.edit_comment(comment, "updated body")

    provider.repo_api.edit_comment.assert_called_once_with(
        owner="owner",
        repo="repo",
        comment_id=expected_id,
        comment="updated body",
    )


def test_gitea_edit_comment_returns_false_on_failure():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.repo_api = MagicMock()
    provider.repo_api.edit_comment.side_effect = RuntimeError("edit failed")
    provider.owner = "owner"
    provider.repo = "repo"
    provider.max_comment_chars = 1000
    provider.logger = MagicMock()

    assert provider.edit_comment({"id": 42}, "updated body") is False


def test_gitea_publish_description_raises_when_update_returns_no_response():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.repo_api = MagicMock()
    provider.repo_api.edit_pull_request.return_value = None
    provider.owner = "owner"
    provider.repo = "repo"
    provider.pr_number = 1
    provider.issue_number = None
    provider.enabled_pr = True
    provider.logger = MagicMock()

    with pytest.raises(RuntimeError, match="Failed to publish PR description"):
        provider.publish_description("AI title", "Updated description")


def test_gitea_get_issue_comments_returns_empty_list_when_no_comments():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.enabled_issue = False
    provider.pr_number = 1
    provider.owner = "owner"
    provider.repo = "repo"
    provider.repo_api = MagicMock()
    provider.repo_api.list_all_comments.return_value = []
    provider.logger = MagicMock()

    assert provider.get_issue_comments() == []


def test_gitea_get_issue_comments_raises_when_api_returns_empty_value():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.enabled_issue = False
    provider.pr_number = 1
    provider.owner = "owner"
    provider.repo = "repo"
    provider.repo_api = MagicMock()
    provider.repo_api.list_all_comments.return_value = None
    provider.logger = MagicMock()

    with pytest.raises(RuntimeError, match="Failed to get comments"):
        provider.get_issue_comments()


def test_gitea_get_issue_comments_raises_when_api_returns_error_payload():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.enabled_issue = False
    provider.pr_number = 1
    provider.owner = "owner"
    provider.repo = "repo"
    provider.repo_api = MagicMock()
    provider.repo_api.list_all_comments.return_value = {
        "error": "unauthorized"
    }
    provider.logger = MagicMock()

    with pytest.raises(RuntimeError, match="Failed to get comments"):
        provider.get_issue_comments()


def test_gitea_get_issue_comments_returns_comment_list():
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.enabled_issue = False
    provider.pr_number = 1
    provider.owner = "owner"
    provider.repo = "repo"
    provider.repo_api = MagicMock()
    comments = [{"body": "comment", "id": 1}]
    provider.repo_api.list_all_comments.return_value = comments
    provider.logger = MagicMock()

    assert provider.get_issue_comments() == comments


@pytest.mark.parametrize(
    ("fallback_on_error", "expected", "publishes_fallback"),
    [(True, "fallback", True), (False, None, False)],
)
def test_gitea_edit_failure_respects_persistent_fallback(
    fallback_on_error, expected, publishes_fallback
):
    header = "## PR Reviewer Guide 🔍"
    provider = GiteaProvider.__new__(GiteaProvider)
    provider.repo_api = MagicMock()
    provider.repo_api.edit_comment.side_effect = RuntimeError("edit failed")
    provider.owner = "owner"
    provider.repo = "repo"
    provider.max_comment_chars = 1000
    provider.logger = MagicMock()
    provider.get_issue_comments = MagicMock(return_value=[{"body": header, "id": 42}])
    provider.get_latest_commit_url = MagicMock(return_value="commit-url")
    provider.get_comment_url = MagicMock(return_value="comment-url")
    provider.publish_comment = MagicMock(return_value="fallback")

    result = GitProvider.publish_persistent_comment_full(
        provider,
        "new review",
        initial_header=header,
        update_header=False,
        final_update_message=False,
        fallback_on_error=fallback_on_error,
    )

    assert result == expected
    if publishes_fallback:
        provider.publish_comment.assert_called_once_with("new review")
    else:
        provider.publish_comment.assert_not_called()


class TestGiteaProvider:
    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_diff_cache_starts_unloaded(self, mock_get_settings, _):
        mock_get_settings.return_value.get.side_effect = lambda key, default=None: {
            "GITEA.PERSONAL_ACCESS_TOKEN": "token",
        }.get(key, default)

        provider = GiteaProvider("https://gitea.example.com/repository")

        assert provider.diff_files is None

    @patch('pr_agent.git_providers.gitea_provider.get_settings')
    @patch('pr_agent.git_providers.gitea_provider.giteapy.ApiClient')
    def test_gitea_provider_auth_header(self, mock_api_client_cls, mock_get_settings):
        # Setup settings
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: {
            'GITEA.URL': 'https://gitea.example.com',
            'GITEA.PERSONAL_ACCESS_TOKEN': 'test-token',
            'GITEA.REPO_SETTING': None,
            'GITEA.SKIP_SSL_VERIFICATION': False,
            'GITEA.SSL_CA_CERT': None
        }.get(k, d)
        mock_get_settings.return_value = settings

        # Setup ApiClient mock
        mock_api_client = mock_api_client_cls.return_value
        # Mock configuration object on client
        mock_api_client.configuration.api_key = {'Authorization': 'token test-token'}

        # Mock responses for calls made during initialization
        def call_api_side_effect(path, method, **kwargs):
            mock_resp = MagicMock()
            if 'files' in path: # get_change_file_pull_request
                mock_resp.data = BytesIO(b'[]')
                return mock_resp
            if 'commits' in path:
                mock_resp.data = BytesIO(b'[]')
                return mock_resp

            # Default fallback
            mock_resp.data = BytesIO(b'{}')
            return mock_resp

        mock_api_client.call_api.side_effect = call_api_side_effect

        from pr_agent.git_providers.gitea_provider import RepoApi

        client = mock_api_client
        repo_api = RepoApi(client)

        # Now test methods independently

        # 1. get_change_file_pull_request
        mock_api_client.reset_mock()
        mock_resp = MagicMock()
        mock_resp.data = BytesIO(b'[]')
        mock_api_client.call_api.return_value = mock_resp

        repo_api.get_change_file_pull_request('owner', 'repo', 123)

        args, kwargs = mock_api_client.call_api.call_args
        assert '/repos/owner/repo/pulls/123/files' in args[0]
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']
        assert 'token=' not in args[0]

        # 2. get_pull_request_diff
        mock_api_client.reset_mock()
        mock_resp = MagicMock()
        mock_resp.data = BytesIO(b'diff content')
        mock_api_client.call_api.return_value = mock_resp

        repo_api.get_pull_request_diff('owner', 'repo', 123)

        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/pulls/123.diff'
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']

        # 3. get_languages
        mock_api_client.reset_mock()
        mock_resp.data = BytesIO(b'{"Python": 100}')
        mock_api_client.call_api.return_value = mock_resp

        repo_api.get_languages('owner', 'repo')

        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/languages'
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']

        # 4. get_file_content
        mock_api_client.reset_mock()
        mock_resp.data = BytesIO(b'content')
        mock_api_client.call_api.return_value = mock_resp

        repo_api.get_file_content('owner', 'repo', 'sha1', 'file.txt')

        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/raw/file.txt'
        assert kwargs.get('query_params') == [('ref', 'sha1')]
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']

        # 5. get_pr_commits
        mock_api_client.reset_mock()
        mock_resp.data = BytesIO(b'[]')
        mock_api_client.call_api.return_value = mock_resp

        repo_api.get_pr_commits('owner', 'repo', 123)

        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/pulls/123/commits'
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']


    @patch('pr_agent.git_providers.gitea_provider.get_settings')
    @patch('pr_agent.git_providers.gitea_provider.giteapy.ApiClient')
    def test_gitea_provider_preserves_non_utf8_text_file_content(self, mock_api_client_cls, mock_get_settings):
        # Regression for the Qodo review on #2440: non-UTF-8 *text* (e.g. UTF-16)
        # must not be dropped to "" (which is indistinguishable from an empty file
        # and loses real content downstream). It is decoded via the shared
        # decode_if_bytes fallback chain instead of crashing or returning "".
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: {
            'GITEA.URL': 'https://gitea.example.com',
            'GITEA.PERSONAL_ACCESS_TOKEN': 'test-token',
            'GITEA.REPO_SETTING': None,
            'GITEA.SKIP_SSL_VERIFICATION': False,
            'GITEA.SSL_CA_CERT': None
        }.get(k, d)
        mock_get_settings.return_value = settings

        mock_api_client = mock_api_client_cls.return_value
        mock_api_client.configuration.api_key = {'Authorization': 'token test-token'}
        mock_resp = MagicMock()
        # UTF-16-LE encoded text — not valid UTF-8, but legitimate text content.
        mock_resp.data = BytesIO("hello world".encode("utf-16"))
        mock_api_client.call_api.return_value = mock_resp

        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(mock_api_client)

        content = repo_api.get_file_content('owner', 'repo', 'sha1', 'notes.txt')
        assert content != '', "non-UTF-8 text must not be dropped to an empty string"
        assert all(ch in content for ch in "hello world"), "the underlying text should survive the fallback decode"
        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/raw/notes.txt'
        assert kwargs.get('query_params') == [('ref', 'sha1')]
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']

    @patch('pr_agent.git_providers.gitea_provider.get_settings')
    @patch('pr_agent.git_providers.gitea_provider.giteapy.ApiClient')
    def test_gitea_provider_does_not_crash_on_binary_file_content(self, mock_api_client_cls, mock_get_settings):
        # The original #2380 crash path: raw binary bytes must not raise
        # UnicodeDecodeError. decode_if_bytes yields a best-effort string; binary
        # files are filtered downstream by extension, so this only needs to not crash.
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: {
            'GITEA.URL': 'https://gitea.example.com',
            'GITEA.PERSONAL_ACCESS_TOKEN': 'test-token',
            'GITEA.REPO_SETTING': None,
            'GITEA.SKIP_SSL_VERIFICATION': False,
            'GITEA.SSL_CA_CERT': None
        }.get(k, d)
        mock_get_settings.return_value = settings

        mock_api_client = mock_api_client_cls.return_value
        mock_api_client.configuration.api_key = {'Authorization': 'token test-token'}
        mock_resp = MagicMock()
        mock_resp.data = BytesIO(b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01')  # JPEG header bytes
        mock_api_client.call_api.return_value = mock_resp

        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(mock_api_client)

        # Must not raise; result is a string (content filtered by extension downstream).
        assert isinstance(repo_api.get_file_content('owner', 'repo', 'sha1', 'assets/image.webp'), str)


    @patch('pr_agent.git_providers.gitea_provider.get_settings')
    @patch('pr_agent.git_providers.gitea_provider.giteapy.ApiClient')
    def test_gitea_provider_decodes_non_utf8_diff_with_replacement(self, mock_api_client_cls, mock_get_settings):
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: {
            'GITEA.URL': 'https://gitea.example.com',
            'GITEA.PERSONAL_ACCESS_TOKEN': 'test-token',
            'GITEA.REPO_SETTING': None,
            'GITEA.SKIP_SSL_VERIFICATION': False,
            'GITEA.SSL_CA_CERT': None
        }.get(k, d)
        mock_get_settings.return_value = settings

        mock_api_client = mock_api_client_cls.return_value
        mock_api_client.configuration.api_key = {'Authorization': 'token test-token'}
        mock_resp = MagicMock()
        mock_resp.data = BytesIO(b'diff --git a/image.png b/image.webp\n+' + bytes([0xff]) + b'binary')
        mock_api_client.call_api.return_value = mock_resp

        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(mock_api_client)

        diff = repo_api.get_pull_request_diff('owner', 'repo', 123)

        assert 'diff --git a/image.png b/image.webp' in diff
        assert '�' in diff
        args, kwargs = mock_api_client.call_api.call_args
        assert args[0] == '/repos/owner/repo/pulls/123.diff'
        assert kwargs.get('auth_settings') == ['AuthorizationHeaderToken']
    def test_get_repo_settings_returns_bytes(self):
        """Regression for #2347: the local settings content returned by get_repo_settings
        must be bytes so that utils.apply_repo_settings can os.write() it and later
        .decode() it. The Gitea raw-file API yields str (unlike GitHub/GitLab/Bitbucket,
        which hand back bytes), so the provider must encode before returning. Global
        settings are disabled to isolate the local path."""
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        toml = '[pr_reviewer]\nnum_code_suggestions = 4\n'
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = 'owner'
        provider.repo = 'repo'
        provider.sha = 'sha1'
        provider.repo_settings = '.pr_agent.toml'
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.return_value = toml  # API decodes to str

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = False
            result = provider.get_repo_settings()

        assert result == [("local", toml.encode('utf-8'))]
        # The bytes must survive the exact operations utils.py performs on them.
        assert result[0][1].decode() == toml

    def test_get_repo_settings_empty_when_unset_or_missing(self):
        """No settings path configured, or empty/absent file: return empty (falsy),
        so apply_repo_settings skips the local file. Global settings are disabled
        to isolate the local path."""
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        unset = GiteaProvider.__new__(GiteaProvider)
        unset.logger = MagicMock()
        unset.repo_settings = None
        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = False
            assert unset.get_repo_settings() == ""

        empty = GiteaProvider.__new__(GiteaProvider)
        empty.logger = MagicMock()
        empty.owner = 'owner'
        empty.repo = 'repo'
        empty.sha = 'sha1'
        empty.repo_settings = '.pr_agent.toml'
        empty.repo_api = MagicMock()
        empty.repo_api.get_file_content.return_value = ''
        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = False
            assert empty.get_repo_settings() == ""

    def test_get_repo_file_content_loads_from_base_sha(self):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.sha = "head-sha"
        provider.base_sha = "base-sha"
        provider.base_ref = "main"
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.return_value = "repo context"

        content = provider.get_repo_file_content("AGENTS.md")

        assert content == "repo context"
        provider.repo_api.get_file_content.assert_called_once_with(
            owner="owner",
            repo="repo",
            commit_sha="base-sha",
            filepath="AGENTS.md"
        )

    def test_get_repo_file_content_loads_from_base_ref_when_base_sha_missing(self):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.sha = "head-sha"
        provider.base_sha = ""
        provider.base_ref = "main"
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.return_value = "repo context"

        content = provider.get_repo_file_content("AGENTS.md")

        assert content == "repo context"
        provider.repo_api.get_file_content.assert_called_once_with(
            owner="owner",
            repo="repo",
            commit_sha="main",
            filepath="AGENTS.md"
        )

    def test_get_repo_file_content_from_default_branch(self):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.base_sha = "base-sha"
        provider.base_ref = "release-1.0"
        provider.sha = "head-sha"
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.repo_get.return_value = MagicMock(default_branch="main")
        provider.repo_api.get_file_content.return_value = "repo context"

        content = provider.get_repo_file_content("AGENTS.md", from_default_branch=True)

        assert content == "repo context"
        provider.repo_api.get_file_content.assert_called_once_with(
            owner="owner",
            repo="repo",
            commit_sha="main",
            filepath="AGENTS.md"
        )

    def test_get_repo_file_content_treats_404_as_missing(self):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.base_sha = "base-sha"
        provider.base_ref = "main"
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.side_effect = ApiException(status=404)

        assert provider.get_repo_file_content("MISSING.md") == ""

    def test_get_repo_file_content_propagates_transient_error(self):
        # Transient/unexpected errors must propagate so the repo-context loader flags a fetch
        # error and does not cache an empty result.
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.base_sha = "base-sha"
        provider.base_ref = "main"
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.side_effect = ApiException(status=500)

        with pytest.raises(ApiException):
            provider.get_repo_file_content("AGENTS.md")

    def test_get_repo_file_content_never_reads_from_pr_head_when_base_missing(self):
        # Security: when no target/base ref is available, the provider must NOT fall back
        # to the PR head (self.sha) — otherwise a PR could supply its own instruction files.
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.owner = "owner"
        provider.repo = "repo"
        provider.sha = "head-sha"
        provider.base_sha = ""
        provider.base_ref = ""
        provider.logger = MagicMock()
        provider.repo_api = MagicMock()
        provider.repo_api.get_file_content.return_value = "repo context"

        content = provider.get_repo_file_content("AGENTS.md")

        assert content == ""
        provider.repo_api.get_file_content.assert_not_called()


class TestGiteaGlobalSettings:
    @pytest.fixture(autouse=True)
    def _clear_global_settings_cache(self):
        # The owner global-settings cache is process-level; clear it between tests.
        from pr_agent.git_providers import git_provider as _gp
        _gp._GLOBAL_SETTINGS_CACHE.clear()
        yield
        _gp._GLOBAL_SETTINGS_CACHE.clear()

    def _make_provider(self, repo_settings=".pr_agent.toml"):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = "owner"
        provider.repo = "repo"
        provider.sha = "head-sha"
        provider.repo_settings = repo_settings
        provider.repo_api = MagicMock()
        return provider

    def test_get_owning_namespace_returns_owner(self):
        provider = self._make_provider()
        assert provider.get_owning_namespace() == "owner"

    def test_get_repo_settings_merges_global_then_local(self):
        global_toml = "[pr_reviewer]\nextra_instructions = \"global\"\n"
        local_toml = "[pr_reviewer]\nextra_instructions = \"local\"\n"
        provider = self._make_provider()
        provider.repo_api.repo_get.return_value = SimpleNamespace(default_branch="main")

        def get_file_content(**kwargs):
            if kwargs["commit_sha"] == "main":
                return global_toml
            return local_toml

        provider.repo_api.get_file_content.side_effect = get_file_content

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = True
            result = provider.get_repo_settings()

        assert result == [("global", global_toml.encode('utf-8')), ("local", local_toml.encode('utf-8'))]

    def test_get_repo_settings_skips_global_when_settings_repo_missing(self):
        local_toml = "[pr_reviewer]\ntemperature = 0.2\n"
        provider = self._make_provider()
        provider.repo_api.repo_get.side_effect = ApiException(status=404)
        provider.repo_api.get_file_content.return_value = local_toml

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = True
            result = provider.get_repo_settings()

        assert result == [("local", local_toml.encode('utf-8'))]

    def test_get_repo_settings_skips_global_when_no_default_branch(self):
        provider = self._make_provider()
        provider.repo_api.repo_get.return_value = SimpleNamespace(default_branch="")
        provider.repo_api.get_file_content.return_value = "[pr_reviewer]\ntemperature = 0.2\n"

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = True
            result = provider.get_repo_settings()

        assert result == [("local", b"[pr_reviewer]\ntemperature = 0.2\n")]

    def test_get_repo_settings_empty_when_global_missing_and_local_unset(self):
        provider = self._make_provider(repo_settings=None)
        provider.repo_api.repo_get.side_effect = ApiException(status=404)

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = True
            result = provider.get_repo_settings()

        assert result == ""

    def test_global_settings_result_is_cached(self):
        provider = self._make_provider()
        provider.repo_api.repo_get.return_value = SimpleNamespace(default_branch="main")
        provider.repo_api.get_file_content.return_value = "[pr_reviewer]\nnum_max_findings = 5\n"

        with patch("pr_agent.git_providers.git_provider.get_settings") as ms:
            ms.return_value.config.use_global_settings_file = True
            assert provider._get_global_repo_settings() == b"[pr_reviewer]\nnum_max_findings = 5\n"
            assert provider._get_global_repo_settings() == b"[pr_reviewer]\nnum_max_findings = 5\n"  # cached

        assert provider.repo_api.repo_get.call_count == 1

    def test_fetch_global_repo_settings_propagates_non_404_errors(self):
        provider = self._make_provider()
        provider.repo_api.repo_get.side_effect = ApiException(status=500)

        with pytest.raises(ApiException):
            provider._fetch_global_repo_settings("owner")


class TestGiteaProviderPRCommits:
    """Regression tests for #2206: the provider must resolve ``last_commit`` from the
    commits of the PR, not from the commits of the repository's default branch.

    ``__init__`` performs network calls, so the instance is built with ``__new__`` and
    only the attributes ``_set_pr_commits`` uses are wired up.
    """

    @staticmethod
    def _provider(pr_commits, head_sha="head-sha"):
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = "owner"
        provider.repo = "repo"
        provider.pr_number = 123
        provider.sha = head_sha
        provider.repo_api = MagicMock()
        provider.repo_api.get_pr_commits.return_value = pr_commits
        return provider

    def test_commits_are_fetched_from_the_pr_not_from_the_repository(self):
        provider = self._provider([{"sha": "head-sha", "html_url": "url/head-sha"}])

        provider._set_pr_commits()

        provider.repo_api.get_pr_commits.assert_called_once_with(
            owner="owner",
            repo="repo",
            pr_number=123
        )
        provider.repo_api.list_all_commits.assert_not_called()

    def test_last_commit_is_the_pr_head_although_gitea_returns_newest_first(self):
        # Gitea returns PR commits newest-first, so the head commit comes first.
        provider = self._provider([
            {"sha": "head-sha", "html_url": "url/head-sha"},
            {"sha": "older-sha", "html_url": "url/older-sha"},
        ])

        provider._set_pr_commits()

        assert provider.last_commit.sha == "head-sha"
        assert provider.last_commit_id is provider.last_commit
        assert provider.get_latest_commit_url() == "url/head-sha"
        # Stored oldest-first, matching the iteration order of the other providers.
        assert [commit.sha for commit in provider.pr_commits] == ["older-sha", "head-sha"]

    def test_last_commit_falls_back_to_newest_commit_when_head_sha_is_unknown(self):
        provider = self._provider([
            {"sha": "newest-sha", "html_url": "url/newest-sha"},
            {"sha": "older-sha", "html_url": "url/older-sha"},
        ], head_sha="")

        provider._set_pr_commits()

        assert provider.last_commit.sha == "newest-sha"

    def test_no_commits_falls_back_to_a_commit_wrapping_the_head_sha(self):
        provider = self._provider([])

        provider._set_pr_commits()

        assert provider.pr_commits == []
        # last_commit must stay a valid object (never None) so callers that dereference
        # last_commit.sha / last_commit_id.sha don't crash, and get a real SHA instead of "".
        assert provider.last_commit is not None
        assert provider.last_commit.sha == "head-sha"
        assert provider.last_commit_id is provider.last_commit
        assert provider.get_latest_commit_url() == ""
        provider.logger.error.assert_called_once()

    def test_non_list_commits_payload_is_treated_as_empty(self):
        provider = self._provider({"message": "not found"})

        provider._set_pr_commits()

        assert provider.pr_commits == []
        assert provider.last_commit.sha == "head-sha"
        provider.logger.error.assert_called()

    def test_file_content_is_read_from_the_pr_head_commit(self):
        provider = self._provider([{"sha": "head-sha", "html_url": "url/head-sha"}])
        provider.repo_api.get_file_content.return_value = "content"

        provider._set_pr_commits()
        provider._get_file_content_from_latest_commit("main.py")

        provider.repo_api.get_file_content.assert_called_once_with(
            owner="owner",
            repo="repo",
            commit_sha="head-sha",
            filepath="main.py"
        )


class TestGiteaProviderAddFileDiff:
    """Tests for GiteaProvider.__add_file_diff diff parsing.

    The provider parses the raw unified diff returned by Gitea into a
    ``{file_path: patch}`` mapping. These tests exercise that parsing in
    isolation, bypassing __init__ (which performs network calls) by building the
    instance with ``__new__`` and wiring up only the attributes the method uses.
    """

    @staticmethod
    def _parse_diff(diff_content):
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = 'owner'
        provider.repo = 'repo'
        provider.pr_number = 1
        provider.file_diffs = {}
        provider.repo_api = MagicMock()
        provider.repo_api.get_pull_request_diff.return_value = diff_content
        # Invoke the name-mangled private method.
        provider._GiteaProvider__add_file_diff()
        return provider.file_diffs

    def test_single_hunk_is_parsed(self):
        diff = (
            'diff --git a/file1.py b/file1.py\n'
            'index 1111111..2222222 100644\n'
            '--- a/file1.py\n'
            '+++ b/file1.py\n'
            '@@ -1,3 +1,4 @@\n'
            ' line1\n'
            '+added line\n'
            ' line2\n'
            ' line3'
        )
        expected = (
            '@@ -1,3 +1,4 @@\n'
            ' line1\n'
            '+added line\n'
            ' line2\n'
            ' line3'
        )
        assert self._parse_diff(diff) == {'file1.py': expected}

    def test_multi_hunk_diff_keeps_all_hunks(self):
        """Regression for multi-hunk diffs (#2137).

        The previous implementation reset ``current_patch`` on every ``@@`` line,
        so only the last hunk of a file survived. All hunks must be preserved.
        """
        diff = (
            'diff --git a/file1.py b/file1.py\n'
            'index 1111111..2222222 100644\n'
            '--- a/file1.py\n'
            '+++ b/file1.py\n'
            '@@ -1,3 +1,4 @@\n'
            ' line1\n'
            '+added line\n'
            ' line2\n'
            ' line3\n'
            '@@ -10,3 +11,4 @@\n'
            ' line10\n'
            '+another added\n'
            ' line11\n'
            ' line12'
        )
        expected = (
            '@@ -1,3 +1,4 @@\n'
            ' line1\n'
            '+added line\n'
            ' line2\n'
            ' line3\n'
            '@@ -10,3 +11,4 @@\n'
            ' line10\n'
            '+another added\n'
            ' line11\n'
            ' line12'
        )
        file_diffs = self._parse_diff(diff)
        assert file_diffs == {'file1.py': expected}
        # Both hunk headers must be present (the bug dropped the first one).
        assert file_diffs['file1.py'].count('@@ -') == 2

    def test_multiple_files_each_with_multiple_hunks(self):
        diff = (
            'diff --git a/file1.py b/file1.py\n'
            'index 1111111..2222222 100644\n'
            '--- a/file1.py\n'
            '+++ b/file1.py\n'
            '@@ -1,2 +1,3 @@\n'
            ' a\n'
            '+b\n'
            ' c\n'
            '@@ -20,2 +21,3 @@\n'
            ' d\n'
            '+e\n'
            ' f\n'
            'diff --git a/file2.py b/file2.py\n'
            'index 3333333..4444444 100644\n'
            '--- a/file2.py\n'
            '+++ b/file2.py\n'
            '@@ -5,2 +5,3 @@\n'
            ' g\n'
            '+h\n'
            ' i\n'
            '@@ -30,2 +31,3 @@\n'
            ' j\n'
            '+k\n'
            ' l'
        )
        file_diffs = self._parse_diff(diff)
        assert set(file_diffs.keys()) == {'file1.py', 'file2.py'}
        assert file_diffs['file1.py'].count('@@ -') == 2
        assert file_diffs['file2.py'].count('@@ -') == 2
        assert file_diffs['file1.py'].startswith('@@ -1,2 +1,3 @@')
        assert file_diffs['file2.py'].startswith('@@ -5,2 +5,3 @@')

    def test_empty_diff_results_in_no_patches(self):
        assert self._parse_diff('') == {}

    def test_api_error_is_swallowed_and_logged(self):
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = 'owner'
        provider.repo = 'repo'
        provider.pr_number = 1
        provider.file_diffs = {}
        provider.repo_api = MagicMock()
        provider.repo_api.get_pull_request_diff.side_effect = Exception('boom')

        provider._GiteaProvider__add_file_diff()

        provider.logger.error.assert_called_once()
        # file_diffs is left untouched when the diff cannot be fetched.
        assert provider.file_diffs == {}

    @patch("pr_agent.git_providers.gitea_provider.giteapy.RepositoryApi")
    def test_edit_pull_request_without_title(self, mock_repository_api_cls):
        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(MagicMock())
        repo_api.edit_pull_request("owner", "repo", 123, "Updated description")

        mock_repository_api_cls.return_value.repo_edit_pull_request.assert_called_once_with(
            owner="owner",
            repo="repo",
            index=123,
            body={"body": "Updated description"}
        )

    @patch("pr_agent.git_providers.gitea_provider.giteapy.RepositoryApi")
    def test_edit_pull_request_with_title(self, mock_repository_api_cls):
        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(MagicMock())
        repo_api.edit_pull_request("owner", "repo", 123, "Updated description", "Updated title")

        mock_repository_api_cls.return_value.repo_edit_pull_request.assert_called_once_with(
            owner="owner",
            repo="repo",
            index=123,
            body={"body": "Updated description", "title": "Updated title"}
        )


class TestGiteaProviderUserFacingLinks:
    """Regression tests for #2612: links published in comments must use the
    user-facing base URL, not the (possibly internal) API base URL.

    ``__init__`` performs network calls, so instances are built with ``__new__``
    and only the attributes under test are wired up. ``base_url`` below stands
    in for an internal address (e.g. a Docker service name) that users cannot
    browse. ``pr_url`` uses the user-facing form throughout: ``_parse_pr_url``
    rejects the API form, so a constructed provider could never carry it, and
    Gitea sets ``url``/``html_url`` on the PR payload to the user-facing page.
    """

    @staticmethod
    def _provider(pr_html_url="", pr_url="http://forgejo:3000/owner/repo/pulls/4", pr_number=4):
        from pr_agent.git_providers.gitea_provider import GiteaProvider

        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = "owner"
        provider.repo = "repo"
        provider.pr_number = pr_number
        provider.base_url = "http://forgejo:3000"
        provider.pr_url = pr_url
        provider.pr = None if pr_html_url is None else MagicMock(html_url=pr_html_url)
        return provider

    @staticmethod
    def _settings(web_url="", configured_url=None):
        # configured_url=None leaves GITEA.URL unset, exercising the derivation path.
        settings = MagicMock()
        values = {"GITEA.WEB_URL": web_url}
        if configured_url is not None:
            values["GITEA.URL"] = configured_url
        settings.get.side_effect = lambda k, d=None: values.get(k, d)
        return settings

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_web_url_setting_takes_precedence(self, mock_get_settings):
        mock_get_settings.return_value = self._settings(
            web_url="https://git.example.com/forgejo/", configured_url="http://forgejo:3000")
        provider = self._provider(pr_html_url="https://other.example.com/owner/repo/pulls/4")

        assert provider._resolve_base_url_html() == "https://git.example.com/forgejo"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_configured_url_preferred_over_pr_html_url(self, mock_get_settings):
        # An operator-set GITEA.URL wins over html_url, which the server builds from
        # its own ROOT_URL - still the (wrong) default on some instances.
        mock_get_settings.return_value = self._settings(configured_url="http://forgejo:3000")
        provider = self._provider(pr_html_url="http://localhost:3000/owner/repo/pulls/4")

        assert provider._resolve_base_url_html() == "http://forgejo:3000"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_shipped_default_url_does_not_shadow_pr_html_url(self, mock_get_settings):
        # configuration.toml always ships url = "https://gitea.com", so the default must not
        # count as operator-set - otherwise the html_url derivation is unreachable in
        # production and the #2612 scenario regresses (review feedback on #2617).
        mock_get_settings.return_value = self._settings(configured_url="https://gitea.com")
        provider = self._provider(pr_html_url="https://git.example.com/forgejo/owner/repo/pulls/4")

        assert provider._resolve_base_url_html() == "https://git.example.com/forgejo"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_shipped_default_url_with_trailing_slash_does_not_shadow(self, mock_get_settings):
        mock_get_settings.return_value = self._settings(configured_url="https://gitea.com/")
        provider = self._provider(pr_html_url="https://git.example.com/forgejo/owner/repo/pulls/4")

        assert provider._resolve_base_url_html() == "https://git.example.com/forgejo"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_derives_base_url_from_pr_html_url(self, mock_get_settings):
        # Zero-config case: Forgejo/Gitea builds html_url from its external ROOT_URL,
        # so the user-facing base URL can be derived even without a web_url setting.
        mock_get_settings.return_value = self._settings()
        provider = self._provider(pr_html_url="https://git.example.com/forgejo/owner/repo/pulls/4")

        assert provider._resolve_base_url_html() == "https://git.example.com/forgejo"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_falls_back_to_base_url_without_pr(self, mock_get_settings):
        # Issue flow has no PR object; existing single-URL deployments stay unchanged.
        mock_get_settings.return_value = self._settings()
        provider = self._provider(pr_html_url=None)

        assert provider._resolve_base_url_html() == "http://forgejo:3000"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_falls_back_to_base_url_when_html_url_missing_or_foreign(self, mock_get_settings):
        mock_get_settings.return_value = self._settings()

        assert self._provider(pr_html_url="")._resolve_base_url_html() == "http://forgejo:3000"
        foreign = self._provider(pr_html_url="https://ci.example.com/artifacts/owner/repo")
        assert foreign._resolve_base_url_html() == "http://forgejo:3000"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_get_line_link_uses_user_facing_base_url(self, mock_get_settings):
        mock_get_settings.return_value = self._settings(web_url="https://git.example.com/forgejo")
        provider = self._provider()
        # Mirror __init__ so the resolver wiring (self.base_url_html assignment) is covered too.
        provider.base_url_html = provider._resolve_base_url_html()
        provider.get_pr_branch = MagicMock(return_value="feat/retry")

        prefix = "https://git.example.com/forgejo/owner/repo/src/branch/feat/retry/app/storage.py"
        assert provider.get_line_link("app/storage.py", 24) == f"{prefix}#L24"
        assert provider.get_line_link("app/storage.py", 24, 30) == f"{prefix}#L24-L30"
        assert provider.get_line_link("app/storage.py", 24, 20) == f"{prefix}#L24-L24"
        assert provider.get_line_link("app/storage.py", 24, "not-a-number") == f"{prefix}#L24"
        assert provider.get_line_link("app/storage.py", -1) == prefix

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_get_pr_url_uses_user_facing_base_url(self, mock_get_settings):
        # html_url here comes from a stale ROOT_URL; the configured WEB_URL must win.
        mock_get_settings.return_value = self._settings(web_url="https://git.example.com/forgejo")
        provider = self._provider(pr_html_url="http://localhost:3000/owner/repo/pulls/4")
        provider.base_url_html = provider._resolve_base_url_html()

        assert provider.get_pr_url() == "https://git.example.com/forgejo/owner/repo/pulls/4"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_get_pr_url_uses_configured_base_url(self, mock_get_settings):
        mock_get_settings.return_value = self._settings(configured_url="http://forgejo:3000")
        provider = self._provider(pr_html_url="http://localhost:3000/owner/repo/pulls/4")
        provider.base_url_html = provider._resolve_base_url_html()

        assert provider.get_pr_url() == "http://forgejo:3000/owner/repo/pulls/4"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_get_pr_url_falls_back_to_raw_pr_url(self, mock_get_settings):
        # Issue flow has no PR number; get_pr_url returns the raw URL unchanged.
        mock_get_settings.return_value = self._settings()
        provider = self._provider(pr_html_url=None, pr_number=None)
        provider.base_url_html = provider._resolve_base_url_html()

        assert provider.get_pr_url() == "http://forgejo:3000/owner/repo/pulls/4"


class TestGiteaProviderUrlParsing:
    """Cover both URL forms: Gitea sets ``pull_request.url`` to the web page,
    Forgejo sets it to ``/api/v1/repos/{owner}/{repo}/pulls/{n}``.

    ``__init__`` performs network calls, so build the provider with ``__new__``
    and exercise the pure helper only.
    """

    @staticmethod
    def _provider():
        return GiteaProvider.__new__(GiteaProvider)

    def test_parse_pr_url_accepts_web_and_api_forms(self):
        provider = self._provider()
        assert provider._parse_pr_url("https://gitea.example.com/owner/repo/pulls/1") == ("owner", "repo", 1)
        assert provider._parse_pr_url(
            "https://gitea.example.com/api/v1/repos/owner/repo/pulls/1") == ("owner", "repo", 1)

    def test_parse_issue_url_accepts_web_and_api_forms(self):
        provider = self._provider()
        assert provider._parse_issue_url("https://gitea.example.com/owner/repo/issues/5") == ("owner", "repo", 5)
        assert provider._parse_issue_url(
            "https://gitea.example.com/api/v1/repos/owner/repo/issues/5") == ("owner", "repo", 5)


class TestGiteaProviderInlineCommentStatus:
    """Regression tests for the ``/improve`` inline-comment path:

    1. ``publish_inline_comments``/``publish_code_suggestions`` never reported
       success or failure, so ``PRCodeSuggestions.push_inline_code_suggestions``
       always treated the call as failed and republished every suggestion a
       second time, duplicating each one.
    2. ``RepoApi.create_inline_comment`` posted to ``pulls/{id}/reviews``
       without an ``event``, which Gitea/Forgejo defaults to a draft review
       (state ``PENDING``) invisible to everyone but its author - there is no
       later step in this flow that submits it.
    """

    @staticmethod
    def _provider(create_inline_comment_result=True):
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = "owner"
        provider.repo = "repo"
        provider.pr_number = 4
        provider.enabled_pr = True
        provider.last_commit = MagicMock(sha="head-sha")
        provider.diff_files = []
        provider.repo_api = MagicMock()
        provider.repo_api.create_inline_comment.return_value = (
            MagicMock() if create_inline_comment_result else None
        )
        return provider

    def test_publish_inline_comments_reports_success(self):
        provider = self._provider(create_inline_comment_result=True)

        assert provider.publish_inline_comments([{"path": "a.py", "body": "x"}]) is True

    def test_publish_inline_comments_reports_failure(self):
        provider = self._provider(create_inline_comment_result=False)

        assert provider.publish_inline_comments([{"path": "a.py", "body": "x"}]) is False

    @pytest.mark.parametrize(
        "error", [ApiException(reason="API rejected the comment"), RuntimeError("transport failed")]
    )
    def test_publish_inline_comments_reports_exception_as_failure(self, error):
        provider = self._provider()
        provider.repo_api.create_inline_comment.side_effect = error

        assert provider.publish_inline_comments([{"path": "a.py", "body": "x"}]) is False

    def test_publish_code_suggestions_does_not_republish_on_success(self):
        # Before the fix, a truthy result here was still treated as failure by
        # PRCodeSuggestions.push_inline_code_suggestions, which republished
        # every suggestion a second time.
        provider = self._provider(create_inline_comment_result=True)
        suggestions = [{"body": "**Suggestion:** fix it", "relevant_file": "a.py",
                        "relevant_lines_start": 3}]

        result = provider.publish_code_suggestions(suggestions)

        assert result is True
        assert provider.repo_api.create_inline_comment.call_count == 1

    def test_publish_code_suggestions_reports_failure(self):
        provider = self._provider(create_inline_comment_result=False)
        suggestions = [{"body": "**Suggestion:** fix it", "relevant_file": "a.py",
                        "relevant_lines_start": 3}]

        assert provider.publish_code_suggestions(suggestions) is False

    def test_publish_code_suggestions_reports_success_on_partial_failure(self):
        # A partial failure must not report failure overall: the caller
        # (PRCodeSuggestions.push_inline_code_suggestions) republishes the whole
        # list on any falsy result, which would post the two already-accepted
        # suggestions a second time. Exactly one create_inline_comment call per
        # suggestion, no retries.
        provider = self._provider()
        provider.repo_api.create_inline_comment.side_effect = [MagicMock(), None, MagicMock()]
        suggestions = [
            {"body": "**Suggestion:** one", "relevant_file": "a.py", "relevant_lines_start": 1},
            {"body": "**Suggestion:** two", "relevant_file": "a.py", "relevant_lines_start": 2},
            {"body": "**Suggestion:** three", "relevant_file": "a.py", "relevant_lines_start": 3},
        ]

        result = provider.publish_code_suggestions(suggestions)

        assert result is True
        assert provider.repo_api.create_inline_comment.call_count == 3

    def test_publish_code_suggestions_reports_success_on_partial_exception(self):
        provider = self._provider()
        provider.repo_api.create_inline_comment.side_effect = [
            MagicMock(), ApiException(reason="API rejected the comment"), MagicMock()
        ]
        suggestions = [
            {"body": "**Suggestion:** one", "relevant_file": "a.py", "relevant_lines_start": 1},
            {"body": "**Suggestion:** two", "relevant_file": "a.py", "relevant_lines_start": 2},
            {"body": "**Suggestion:** three", "relevant_file": "a.py", "relevant_lines_start": 3},
        ]

        result = provider.publish_code_suggestions(suggestions)

        assert result is True
        assert provider.repo_api.create_inline_comment.call_count == 3

    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    def test_create_inline_comment_submits_as_comment_not_pending(self, mock_api_client_cls):
        from pr_agent.git_providers.gitea_provider import RepoApi

        client = mock_api_client_cls.return_value
        client.call_api.return_value = MagicMock()
        repo_api = RepoApi(client)

        repo_api.create_inline_comment(
            owner="owner", repo="repo", pr_number=4,
            body="Inline comment", commit_id="head-sha",
            comments=[{"path": "a.py", "body": "x"}],
        )

        _, kwargs = client.call_api.call_args
        assert kwargs["body"]["event"] == "COMMENT"


def test_gitea_persistent_wrapper_preserves_identity_and_result():
    published = object()

    class RecordingGiteaProvider:
        # Gitea no longer overrides this: the base implementation persists.
        publish_persistent_comment = GiteaProvider.publish_persistent_comment
        supports_comment_editing = GitProvider.supports_comment_editing

        def __init__(self):
            self.calls = []

        def edit_comment(self, comment, body):
            return True

        def publish_persistent_comment_full(
            self, pr_comment, initial_header, update_header=True, name="review",
            final_update_message=True, as_thread=False, identity_marker=None,
            legacy_initial_header=None, require_agent_authorship=False,
            fallback_on_error=True,
        ):
            self.calls.append((
                pr_comment, initial_header, update_header, name,
                final_update_message, as_thread, identity_marker,
                legacy_initial_header, require_agent_authorship, fallback_on_error,
            ))
            return published

    provider = RecordingGiteaProvider()
    result = provider.publish_persistent_comment(
        "review body",
        "initial header",
        update_header=False,
        name="review",
        final_update_message=False,
        identity_marker="marker",
        legacy_initial_header="legacy header",
    )

    assert result is published
    assert provider.calls == [(
        "review body", "initial header", False, "review", False,
        False, "marker", "legacy header", False, True,
    )]


def _page(items):
    """A raw (non-preloaded) giteapy response carrying one JSON page."""
    return SimpleNamespace(data=BytesIO(json.dumps(items).encode("utf-8")))


class TestGiteaRepoApiPagination:
    """Gitea answers list endpoints one page at a time (30 items by default), so the PR
    files and commits must be collected across every page."""

    @staticmethod
    def _repo_api(pages):
        from pr_agent.git_providers.gitea_provider import RepoApi

        repo_api = RepoApi(MagicMock())
        repo_api.logger = MagicMock()
        repo_api.api_client.call_api.side_effect = [_page(items) for items in pages]
        return repo_api

    @staticmethod
    def _requested_pages(repo_api):
        return [dict(call.kwargs["query_params"])["page"] for call in repo_api.api_client.call_api.call_args_list]

    def test_pr_files_are_collected_across_pages(self):
        repo_api = self._repo_api([
            [{"filename": "a.py"}, {"filename": "b.py"}],
            [{"filename": "c.py"}],
            [],
        ])

        files = repo_api.get_change_file_pull_request(owner="owner", repo="repo", pr_number=7)

        assert [f["filename"] for f in files] == ["a.py", "b.py", "c.py"]
        assert self._requested_pages(repo_api) == [1, 2, 3]

    def test_pr_commits_are_collected_across_pages(self):
        repo_api = self._repo_api([
            [{"sha": "newest"}, {"sha": "middle"}],
            [{"sha": "oldest"}],
            [],
        ])

        commits = repo_api.get_pr_commits(owner="owner", repo="repo", pr_number=7)

        assert [c["sha"] for c in commits] == ["newest", "middle", "oldest"]
        assert self._requested_pages(repo_api) == [1, 2, 3]

    def test_a_page_shorter_than_the_requested_limit_is_not_the_last_page(self):
        # A server capped at 30 items answers a limit of 50 with 30 items; only an empty
        # page ends the walk, otherwise the original truncation would be back.
        repo_api = self._repo_api([
            [{"sha": str(i)} for i in range(30)],
            [{"sha": str(i)} for i in range(30, 35)],
            [],
        ])

        commits = repo_api.get_pr_commits(owner="owner", repo="repo", pr_number=7)

        assert len(commits) == 35
        assert self._requested_pages(repo_api) == [1, 2, 3]

    def test_every_page_request_authenticates_via_header(self):
        repo_api = self._repo_api([[{"filename": "a.py"}], []])

        repo_api.get_change_file_pull_request(owner="owner", repo="repo", pr_number=7)

        for call in repo_api.api_client.call_api.call_args_list:
            assert call.kwargs["auth_settings"] == ["AuthorizationHeaderToken"]
            assert "token" not in dict(call.kwargs["query_params"])

    def test_a_failure_mid_way_does_not_return_a_partial_list(self):
        repo_api = self._repo_api([])
        repo_api.api_client.call_api.side_effect = [_page([{"filename": "a.py"}]), ApiException(status=502)]

        files = repo_api.get_change_file_pull_request(owner="owner", repo="repo", pr_number=7)

        assert files == []
        repo_api.logger.error.assert_called_once()


class TestBaseUrlHtmlIsResolvedOnFirstUse:
    """apply_repo_settings builds the provider before it merges the repo's .pr_agent.toml,
    so a user-facing URL fixed in the constructor would ignore a repo-level web_url."""

    @staticmethod
    def _settings(values):
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: values.get(k, d)
        return settings

    @staticmethod
    def _provider():
        provider = GiteaProvider.__new__(GiteaProvider)
        provider.logger = MagicMock()
        provider.owner = "owner"
        provider.repo = "repo"
        provider.pr_number = 4
        provider.base_url = "http://forgejo:3000"
        provider.pr = MagicMock(html_url="http://forgejo:3000/owner/repo/pulls/4")
        provider.get_pr_branch = MagicMock(return_value="feature")
        return provider

    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_the_constructor_leaves_the_url_unresolved(self, mock_get_settings, _):
        mock_get_settings.return_value = self._settings({"GITEA.PERSONAL_ACCESS_TOKEN": "token"})

        provider = GiteaProvider("https://gitea.example.com/repository")

        assert provider._base_url_html is None

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_a_web_url_merged_after_construction_is_honoured(self, mock_get_settings):
        values = {"GITEA.WEB_URL": ""}
        mock_get_settings.return_value = self._settings(values)
        provider = self._provider()
        # The repo's .pr_agent.toml lands after the provider exists and before any link is built.
        values["GITEA.WEB_URL"] = "https://git.example.com"

        link = provider.get_line_link("src/app.py", 7)

        assert link == "https://git.example.com/owner/repo/src/branch/feature/src/app.py#L7"
        assert provider.get_pr_url() == "https://git.example.com/owner/repo/pulls/4"

    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_the_url_is_resolved_once(self, mock_get_settings):
        values = {"GITEA.WEB_URL": "https://git.example.com"}
        mock_get_settings.return_value = self._settings(values)
        provider = self._provider()

        first = provider.base_url_html
        values["GITEA.WEB_URL"] = "https://changed.example.com"

        assert provider.base_url_html == first == "https://git.example.com"

    def test_an_assigned_url_is_used_as_is(self):
        provider = self._provider()

        provider.base_url_html = "https://assigned.example.com"

        assert provider.base_url_html == "https://assigned.example.com"


class TestGiteaRepoIgnoreRules:
    """Regression for #2620: repository-level [ignore] rules from .pr_agent.toml
    are merged into settings AFTER GiteaProvider is constructed (so the eager
    filter in __init__ could never see them). The filter now runs inside
    get_diff_files(), at diff time, when the merged repo settings are in effect.
    """

    GITEA_SETTINGS = {
        "GITEA.URL": "https://gitea.example.com",
        "GITEA.PERSONAL_ACCESS_TOKEN": "test-token",
        "GITEA.REPO_SETTING": None,
        "GITEA.SKIP_SSL_VERIFICATION": False,
        "GITEA.SSL_CA_CERT": None,
    }

    FILES = [
        {"filename": "generated/client.py", "additions": 10, "deletions": 0, "status": "added"},
        {"filename": "api/schema.d.ts", "additions": 5, "deletions": 0, "status": "modified"},
        {"filename": "src/application.py", "additions": 3, "deletions": 1, "status": "modified"},
    ]

    def _build_provider(self, mock_repo_api_cls, mock_get_settings, mock_api_client_cls):
        settings = MagicMock()
        settings.get.side_effect = lambda k, d=None: self.GITEA_SETTINGS.get(k, d)
        mock_get_settings.return_value = settings

        repo_api = mock_repo_api_cls.return_value
        pr = SimpleNamespace(
            head=SimpleNamespace(sha="head-sha"),
            base=SimpleNamespace(sha="base-sha", ref="main"),
        )
        repo_api.get_pull_request.return_value = pr
        repo_api.get_change_file_pull_request.return_value = self.FILES
        repo_api.get_file_content.return_value = "file content"
        repo_api.get_pull_request_diff.return_value = (
            "diff --git a/generated/client.py b/generated/client.py\n"
            "@@ -1 +1 @@\n-old\n+new\n"
            "diff --git a/api/schema.d.ts b/api/schema.d.ts\n"
            "@@ -1 +1 @@\n-old\n+new\n"
            "diff --git a/src/application.py b/src/application.py\n"
            "@@ -1 +1 @@\n-old\n+new\n"
        )
        repo_api.get_pr_commits.return_value = [{"sha": "head-sha"}]

        from pr_agent.git_providers.gitea_provider import GiteaProvider

        return GiteaProvider("https://gitea.example.com/owner/repo/pulls/1")

    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    @patch("pr_agent.git_providers.gitea_provider.RepoApi")
    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_repo_ignore_globs_exclude_files_at_diff_time(
        self, mock_get_settings, mock_repo_api_cls, mock_api_client_cls
    ):
        """Construct the provider with NO ignore rules (as happens before
        apply_repo_settings merges the repo .pr_agent.toml), then merge the
        repo's [ignore] rules into the request settings and confirm
        get_diff_files() drops the matching files."""
        provider = self._build_provider(mock_repo_api_cls, mock_get_settings, mock_api_client_cls)

        with request_cycle_context({}):
            context["settings"] = copy.deepcopy(global_settings)
            context["settings"].ignore.glob = ["generated/**", "api/schema.d.ts"]
            context["settings"].ignore.regex = []

            diff_files = provider.get_diff_files()
            names = [f.filename for f in diff_files]

            assert "src/application.py" in names
            assert "generated/client.py" not in names, \
                "repo-level glob 'generated/**' must exclude generated/client.py"
            assert "api/schema.d.ts" not in names, \
                "repo-level glob 'api/schema.d.ts' must exclude api/schema.d.ts"

    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    @patch("pr_agent.git_providers.gitea_provider.RepoApi")
    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_no_ignore_rules_keeps_all_files(
        self, mock_get_settings, mock_repo_api_cls, mock_api_client_cls
    ):
        provider = self._build_provider(mock_repo_api_cls, mock_get_settings, mock_api_client_cls)

        with request_cycle_context({}):
            context["settings"] = copy.deepcopy(global_settings)
            context["settings"].ignore.glob = []
            context["settings"].ignore.regex = []

            names = [f.filename for f in provider.get_diff_files()]
            assert sorted(names) == ["api/schema.d.ts", "generated/client.py", "src/application.py"]

    @patch("pr_agent.git_providers.gitea_provider.giteapy.ApiClient")
    @patch("pr_agent.git_providers.gitea_provider.RepoApi")
    @patch("pr_agent.git_providers.gitea_provider.get_settings")
    def test_large_pr_skips_unused_head_content_fetches(
        self, mock_get_settings, mock_repo_api_cls, mock_api_client_cls
    ):
        provider = self._build_provider(mock_repo_api_cls, mock_get_settings, mock_api_client_cls)
        repo_api = mock_repo_api_cls.return_value

        with request_cycle_context({}), patch(
            "pr_agent.git_providers.gitea_provider.MAX_FILES_ALLOWED_FULL", 2
        ):
            context["settings"] = copy.deepcopy(global_settings)
            context["settings"].ignore.glob = []
            context["settings"].ignore.regex = []

            diff_files = provider.get_diff_files()

        head_calls = [
            call.kwargs["filepath"]
            for call in repo_api.get_file_content.call_args_list
            if call.kwargs.get("commit_sha") == "head-sha"
        ]
        assert head_calls == ["generated/client.py"]
        assert [file.head_file for file in diff_files] == ["file content", "", ""]
