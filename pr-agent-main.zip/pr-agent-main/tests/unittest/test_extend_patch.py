import pytest

from pr_agent.algo.git_patch_processing import (
    RE_HUNK_HEADER,
    extend_patch,
    extract_hunk_headers,
    extract_hunk_lines_from_patch,
)
from pr_agent.algo.pr_processing import pr_generate_extended_diff
from pr_agent.algo.token_handler import TokenHandler
from pr_agent.algo.utils import load_large_diff
from pr_agent.config_loader import get_settings

get_settings(use_context=False).set("CONFIG.CLI_MODE", True)
get_settings(use_context=False).config.allow_dynamic_context = False


class TestExtendPatch:
    # Tests that the function works correctly with valid input
    def test_happy_path(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5'
        patch_str = '@@ -2,2 +2,2 @@ init()\n-line2\n+new_line2\n line3'
        num_lines = 1
        expected_output = '\n@@ -1,4 +1,4 @@ init()\n line1\n-line2\n+new_line2\n line3\n line4'
        actual_output = extend_patch(original_file_str, patch_str,
                                     patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines)
        assert actual_output == expected_output

    # Tests that the function returns an empty string when patch_str is empty
    def test_empty_patch(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5'
        patch_str = ''
        num_lines = 1
        expected_output = ''
        assert extend_patch(original_file_str, patch_str,
                            patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines) == expected_output

    # Tests that the function returns the original patch when num_lines is 0
    def test_zero_num_lines(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5'
        patch_str = '@@ -2,2 +2,2 @@ init()\n-line2\n+new_line2\nline3'
        num_lines = 0
        assert extend_patch(original_file_str, patch_str,
                            patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines) == patch_str

    # Tests that the function returns the original patch when patch_str contains no hunks
    def test_no_hunks(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5'
        patch_str = 'no hunks here'
        num_lines = 1
        expected_output = 'no hunks here'
        assert extend_patch(original_file_str, patch_str, num_lines) == expected_output

    # Tests that the function extends a patch with a single hunk correctly
    def test_single_hunk(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5'
        patch_str = '@@ -2,3 +2,3 @@ init()\n-line2\n+new_line2\n line3\n line4'

        for num_lines in [1, 2, 3]:  # still works if extra lines exceed the file
            expected_output = '\n@@ -1,5 +1,5 @@ init()\n line1\n-line2\n+new_line2\n line3\n line4\n line5'
            actual_output = extend_patch(original_file_str, patch_str,
                                         patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines)
            assert actual_output == expected_output

    # Tests the functionality of extending a patch with multiple hunks.
    def test_multiple_hunks(self):
        original_file_str = 'line1\nline2\nline3\nline4\nline5\nline6'
        patch_str = '@@ -2,3 +2,3 @@ init()\n-line2\n+new_line2\n line3\n line4\n@@ -4,1 +4,1 @@ init2()\n-line4\n+new_line4'  # noqa: E501
        num_lines = 1
        original_allow_dynamic_context = get_settings(use_context=False).config.allow_dynamic_context

        get_settings(use_context=False).config.allow_dynamic_context = False
        expected_output = '\n@@ -1,5 +1,5 @@ init()\n line1\n-line2\n+new_line2\n line3\n line4\n line5\n\n@@ -3,3 +3,3 @@ init2()\n line3\n-line4\n+new_line4\n line5' # noqa: E501
        actual_output = extend_patch(original_file_str, patch_str,
                                     patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines)
        assert actual_output == expected_output

        get_settings(use_context=False).config.allow_dynamic_context = True
        expected_output = '\n@@ -1,5 +1,5 @@ init()\n line1\n-line2\n+new_line2\n line3\n line4\n line5\n\n@@ -3,3 +3,3 @@ init2()\n line3\n-line4\n+new_line4\n line5' # noqa: E501
        actual_output = extend_patch(original_file_str, patch_str,
                                     patch_extra_lines_before=num_lines, patch_extra_lines_after=num_lines)
        assert actual_output == expected_output
        get_settings(use_context=False).config.allow_dynamic_context = original_allow_dynamic_context


    def test_dynamic_context(self):
        get_settings(use_context=False).config.max_extra_lines_before_dynamic_context = 10
        original_file_str = "def foo():"
        for i in range(9):
            original_file_str += f"\n    line({i})"
        patch_str ="@@ -10,1 +10,1 @@ def foo():\n-    line(8)\n+    new_line(8)"
        new_file_str = "\n".join(original_file_str.splitlines()[:-1] + ["    new_line(8)"])
        num_lines=1

        get_settings(use_context=False).config.allow_dynamic_context = True
        actual_output = extend_patch(
            original_file_str,
            patch_str,
            patch_extra_lines_before=num_lines,
            patch_extra_lines_after=num_lines,
            new_file_str=new_file_str,
        )
        expected_output = (
            "\n@@ -1,10 +1,10 @@ \n def foo():\n     line(0)\n     line(1)\n"
            "     line(2)\n     line(3)\n     line(4)\n     line(5)\n     line(6)\n"
            "     line(7)\n-    line(8)\n+    new_line(8)"
        )
        assert actual_output == expected_output

        get_settings(use_context=False).config.allow_dynamic_context = False
        actual_output2 = extend_patch(original_file_str, patch_str,
                                     patch_extra_lines_before=1, patch_extra_lines_after=1)
        expected_output_no_dynamic_context = (
            "\n@@ -9,2 +9,2 @@ def foo():\n     line(7)\n-    line(8)\n+    new_line(8)"
        )
        assert actual_output2 == expected_output_no_dynamic_context

        get_settings(use_context=False).config.allow_dynamic_context = False
        actual_output3 = extend_patch(original_file_str, patch_str,
                                     patch_extra_lines_before=3, patch_extra_lines_after=3)
        expected_output_no_dynamic_context = (
            "\n@@ -7,4 +7,4 @@ def foo():\n     line(5)\n     line(6)\n     line(7)\n"
            "-    line(8)\n+    new_line(8)"
        )
        assert actual_output3 == expected_output_no_dynamic_context





class TestExtendedPatchMoreLines:
    class File:
        def __init__(self, base_file, patch, head_file, filename, ai_file_summary=None):
            self.base_file = base_file
            self.patch = patch
            self.head_file = head_file
            self.filename = filename
            self.ai_file_summary = ai_file_summary

    @pytest.fixture
    def token_handler(self):
        # Create a TokenHandler instance with dummy data
        th = TokenHandler(system="System prompt", user="User prompt")
        th.prompt_tokens = 100
        return th

    @pytest.fixture
    def pr_languages(self):
        # Create a list of languages with files containing base_file and patch data
        return [
            {
                "files": [
                    self.File(
                        base_file=(
                            "line000\nline00\nline0\nline1\noriginal content\n"
                            "line2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10"
                        ),
                        patch=(
                            "@@ -5,5 +5,5 @@\n-original content\n+modified content\n"
                            " line2\n line3\n line4\n line5"
                        ),
                        head_file=(
                            "line000\nline00\nline0\nline1\nmodified content\n"
                            "line2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10"
                        ),
                        filename="file1",
                    ),
                    self.File(
                        base_file=(
                            "original content\nline2\nline3\nline4\nline5\n"
                            "line6\nline7\nline8\nline9\nline10"
                        ),
                        patch="@@ -6,5 +6,5 @@\nline6\nline7\nline8\n-line9\n+modified line9\nline10",
                        head_file=(
                            "original content\nline2\nline3\nline4\nline5\n"
                            "line6\nline7\nline8\nmodified line9\nline10"
                        ),
                        filename="file2",
                    ),
                ]
            }
        ]

    def test_extend_patches_with_extra_lines(self, token_handler, pr_languages):
        patches_extended_no_extra_lines, total_tokens, patches_extended_tokens = pr_generate_extended_diff(
            pr_languages, token_handler, add_line_numbers_to_hunks=False,
            patch_extra_lines_before=0,
            patch_extra_lines_after=0
        )

        # Check that with no extra lines, the patches are the same as the original patches
        p0 = patches_extended_no_extra_lines[0].strip()
        p1 = patches_extended_no_extra_lines[1].strip()
        assert p0 == "## File: 'file1'\n\n" + pr_languages[0]['files'][0].patch.strip()
        assert p1 == "## File: 'file2'\n\n" + pr_languages[0]['files'][1].patch.strip()

        patches_extended_with_extra_lines, total_tokens, patches_extended_tokens = pr_generate_extended_diff(
            pr_languages, token_handler, add_line_numbers_to_hunks=False,
            patch_extra_lines_before=2,
            patch_extra_lines_after=1
        )

        p0_extended = patches_extended_with_extra_lines[0].strip()
        assert p0_extended == (
            "## File: 'file1'\n\n@@ -3,8 +3,8 @@ \n line0\n line1\n"
            "-original content\n+modified content\n line2\n line3\n line4\n line5\n line6"
        )

class TestLoadLargeDiff:
    @pytest.mark.parametrize("old_ending", ["", "\n"])
    @pytest.mark.parametrize("new_ending", ["", "\n"])
    def test_no_newline(self, old_ending, new_ending):
        original = "old content 1\nold content 2" + old_ending
        new = "old content 1\nsome new content\nanother line" + new_ending
        expected = (
            "@@ -1,2 +1,3 @@\n old content 1\n-old content 2\n"
            "+some new content\n+another line\n"
        )
        assert load_large_diff("test.py", new, original) == expected

    @pytest.mark.parametrize("original", [None, ""])
    @pytest.mark.parametrize("new", [None, ""])
    def test_empty_inputs(self, original, new):
        assert load_large_diff("test.py", new, original) == ""

    @pytest.mark.parametrize("empty", [None, ""])
    @pytest.mark.parametrize("content", ["content\n", "  \n", "\n"])
    def test_empty_sides_have_zero_line_ranges(self, empty, content):
        assert load_large_diff("test.py", content, empty) == "@@ -0,0 +1 @@\n+" + content
        assert load_large_diff("test.py", empty, content) == "@@ -1 +0,0 @@\n-" + content

    @pytest.mark.parametrize("ending", ["", "\n", "\r\n"])
    @pytest.mark.parametrize("whitespace", ["  ", "\t"])
    def test_preserves_trailing_spaces_and_tabs(self, whitespace, ending):
        original = "value" + ending
        new = "value" + whitespace + ending
        line_ending = ending or "\n"
        assert load_large_diff("test.py", new, original) == (
            f"@@ -1 +1 @@\n-value{line_ending}+value{whitespace}{line_ending}"
        )
        assert load_large_diff("test.py", original, new) == (
            f"@@ -1 +1 @@\n-value{whitespace}{line_ending}+value{line_ending}"
        )

    @pytest.mark.parametrize("ending", ["\n", "\r\n"])
    def test_preserves_trailing_blank_lines(self, ending):
        original = "value" + ending
        new = original + ending
        assert load_large_diff("test.py", new, original) == (
            f"@@ -1 +1,2 @@\n value{ending}+{ending}"
        )
        assert load_large_diff("test.py", original, new) == (
            f"@@ -1,2 +1 @@\n value{ending}-{ending}"
        )

    @pytest.mark.parametrize("content", ["value  \n", "value\t\r\n", "value\n\n", "  "])
    def test_unchanged_whitespace_has_no_diff(self, content):
        assert load_large_diff("test.py", content, content) == ""


class TestOmittedHunkCount:
    def test_omitted_count_is_parsed_as_one(self):
        section_header, size1, size2, start1, start2 = extract_hunk_headers(
            RE_HUNK_HEADER.match("@@ -1 +1 @@"))
        assert (start1, size1, start2, size2) == (1, 1, 1, 1)

    def test_omitted_count_on_one_side_only(self):
        section_header, size1, size2, start1, start2 = extract_hunk_headers(
            RE_HUNK_HEADER.match("@@ -10,7 +12 @@"))
        assert (start1, size1, start2, size2) == (10, 7, 12, 1)

    def test_single_line_hunk_does_not_resurrect_the_deleted_line(self):
        original = "".join(f"l{i}\n" for i in range(1, 9))
        new = "CHANGED\n" + "".join(f"l{i}\n" for i in range(2, 9))
        extended = extend_patch(original, "@@ -1 +1 @@\n-l1\n+CHANGED",
                                patch_extra_lines_before=0, patch_extra_lines_after=3,
                                filename="m.py", new_file_str=new)
        assert "\n l1" not in extended
        for expected in (" l2", " l3", " l4"):
            assert expected in extended

    def test_hunk_line_range_excludes_the_line_after_the_hunk(self):
        patch = ("@@ -10,1 +12 @@\n-old\n+only_line\n"
                 "@@ -20,3 +20,3 @@\n ctx20\n-old21\n+new21\n ctx22")
        full, _ = extract_hunk_lines_from_patch(patch, "f.py", 13, 13, "right")
        assert "@@ -10,1 +12 @@" not in full
