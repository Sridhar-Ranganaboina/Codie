import asyncio
import copy
import hashlib
import hmac
import json
import os
from datetime import datetime

import uvicorn
from fastapi import APIRouter, FastAPI, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from starlette.background import BackgroundTasks
from starlette.middleware import Middleware
from starlette_context import context
from starlette_context.middleware import RawContextMiddleware

from pr_agent.agent.pr_agent import PRAgent, prepare_command
from pr_agent.config_loader import get_settings, global_settings
from pr_agent.git_providers import get_git_provider_with_context
from pr_agent.git_providers.utils import apply_repo_settings
from pr_agent.log import LoggingFormat, get_logger, setup_logger
from pr_agent.secret_providers import get_secret_provider, validate_secret_provider_setting
from pr_agent.servers.utils import (
    get_pr_commands,
    push_trigger_slot,
    shared_should_process_pr_logic,
)
from pr_agent.telemetry.prometheus import attach_metrics_endpoint, prometheus_metrics_enabled

setup_logger(fmt=LoggingFormat.JSON, level=get_settings().get("CONFIG.LOG_LEVEL", "DEBUG"))
router = APIRouter()


# Validated at import so a typo in CONFIG.SECRET_PROVIDER still fails at startup. The
# client itself is deliberately not built here - see get_fork_safe_secret_provider.
validate_secret_provider_setting()

_secret_provider_state = {}


def get_fork_safe_secret_provider():
    """Return this process's secret provider, building it on first use.

    Nothing is constructed at import because gunicorn runs with `preload_app`: a client
    built there would belong to the master, and every worker would inherit its pooled
    connection. Keying the cache on the pid means a forked worker always builds its own,
    and never adopts one created in another process.
    """
    pid = os.getpid()
    if _secret_provider_state.get("pid") != pid:
        _secret_provider_state["provider"] = get_secret_provider()
        _secret_provider_state["pid"] = pid
    return _secret_provider_state["provider"]


async def handle_request(api_url: str, body: str, log_context: dict, sender_id: str, notify=None):
    log_context["action"] = body
    log_context["event"] = "pull_request" if body == "/review" else "comment"
    log_context["api_url"] = api_url
    log_context["app_name"] = get_settings().get("CONFIG.APP_NAME", "Unknown")

    # Comment commands can pass arbitrary arguments, so sibling-repo context is authorized
    # against the commenter (the command actor) instead of the MR author. Fail closed when no
    # trustworthy account can be recorded (e.g. the "unknown" fallback for missing sender data).
    if isinstance(sender_id, int) and sender_id:
        provider = get_git_provider_with_context(pr_url=api_url)
        if hasattr(provider, "set_command_actor"):
            provider.set_command_actor(sender_id)

    with get_logger().contextualize(**log_context):
        await PRAgent().handle_request(api_url, body, notify)

async def _perform_commands_gitlab(commands_conf: str, agent: PRAgent, api_url: str,
                                   log_context: dict, data: dict):
    feedback_on_draft = get_settings().get(
        "gitlab.feedback_on_draft_pr", False
    )
    if is_draft(data) and not feedback_on_draft:
        get_logger().info(f"Skipping draft MR: {api_url}")
        return
    # auto commands for PR, and auto feedback is disabled
    if commands_conf == "pr_commands" and get_settings().config.disable_auto_feedback:
        get_logger().info(f"Auto feedback is disabled, skipping auto commands for PR {api_url=}", **log_context)
        return
    if not should_process_pr_logic(data): # Here we already updated the configurations
        return
    commands = (
        get_pr_commands("gitlab")
        if commands_conf == "pr_commands"
        else get_settings().get(f"gitlab.{commands_conf}", {})
    )
    get_settings().set("config.is_auto_command", True)
    for command in commands:
        try:
            new_command = prepare_command(command)
            get_logger().info(f"Performing command: {new_command}")
            with get_logger().contextualize(**log_context):
                await agent.handle_request(api_url, new_command)
        except Exception as e:
            get_logger().error(f"Failed to perform command {command}: {e}")


def is_bot_user(data) -> bool:
    try:
        # logic to ignore bot users (unlike GitHub, no direct flag for bot users in gitlab)
        sender_name = data.get("user", {}).get("name", "unknown").lower()
        # Indicators are sourced from config.bot_user_indicators in configuration.toml so the
        # default list has a single source of truth and can be reused by other providers in
        # the future. Normalize the value defensively: a misconfigured .pr_agent.toml (string
        # instead of list, non-string entries) should not break bot detection, and matching
        # is documented as case-insensitive.
        raw_indicators = get_settings().get("config.bot_user_indicators", [])
        if isinstance(raw_indicators, str):
            raw_indicators = [raw_indicators]
        try:
            raw_indicators = list(raw_indicators)
        except TypeError:
            get_logger().warning(
                f"Ignoring non-iterable gitlab.bot_user_indicators value: {raw_indicators!r}"
            )
            raw_indicators = []
        bot_indicators = [s.lower() for s in raw_indicators if isinstance(s, str)]
        if any(indicator in sender_name for indicator in bot_indicators):
            get_logger().info(f"Skipping GitLab bot user: {sender_name}")
            return True
    except Exception as e:
        get_logger().error(f"Failed 'is_bot_user' logic: {e}")
    return False

def is_draft(data) -> bool:
    try:
        if 'draft' in data.get('object_attributes', {}):
            return data['object_attributes']['draft']

        # for gitlab server version before 16
        elif 'Draft:' in (data.get('object_attributes', {}).get('title') or ''):
            return True
    except Exception as e:
        get_logger().error(f"Failed 'is_draft' logic: {e}")
    return False

def is_draft_ready(data) -> bool:
    try:
        if 'draft' in data.get('changes', {}):
            # Handle both boolean values and string values for compatibility
            previous = data['changes']['draft']['previous']
            current = data['changes']['draft']['current']

            # Convert to boolean if they're strings
            if isinstance(previous, str):
                previous = previous.lower() == 'true'
            if isinstance(current, str):
                current = current.lower() == 'true'

            if previous is True and current is False:
                return True

        # for gitlab server version before 16
        elif 'title' in data.get('changes', {}):
            if 'Draft:' in data['changes']['title']['previous'] and 'Draft:' not in data['changes']['title']['current']:
                return True
    except Exception as e:
        get_logger().error(f"Failed 'is_draft_ready' logic: {e}")
    return False

_bot_user_id_cache = {}

async def _get_bot_user_id():
    gitlab_url = get_settings().get("GITLAB.URL", "https://gitlab.com")
    gitlab_token = get_settings().get("GITLAB.PERSONAL_ACCESS_TOKEN", None)
    if not gitlab_token:
        get_logger().error("No GitLab token available for bot user ID resolution")
        return None

    cache_key = hashlib.sha256(f"{gitlab_url}:{gitlab_token}".encode()).hexdigest()

    cached = _bot_user_id_cache.get(cache_key)
    if cached is not None:
        return cached

    def _resolve_sync():
        import gitlab

        ssl_verify = get_settings().get("GITLAB.SSL_VERIFY", True)
        if isinstance(ssl_verify, str) and ssl_verify.lower() in ("true", "false"):
            ssl_verify = ssl_verify.lower() == "true"

        auth_method = get_settings().get("GITLAB.AUTH_TYPE", "oauth_token")
        if auth_method not in ("oauth_token", "private_token"):
            raise ValueError(
                f"Unsupported GITLAB.AUTH_TYPE: '{auth_method}'. "
                f"Must be 'oauth_token' or 'private_token'."
            )

        if auth_method == "oauth_token":
            gl = gitlab.Gitlab(
                url=gitlab_url,
                oauth_token=gitlab_token,
                ssl_verify=ssl_verify
            )
        else:
            gl = gitlab.Gitlab(
                url=gitlab_url,
                private_token=gitlab_token,
                ssl_verify=ssl_verify
            )
        gl.auth()
        return gl.user.id

    try:
        user_id = await asyncio.to_thread(_resolve_sync)
        if len(_bot_user_id_cache) > 1000:
            _bot_user_id_cache.clear()
        _bot_user_id_cache[cache_key] = user_id
        get_logger().info(f"Bot user ID resolved via API: {user_id}")
        return user_id
    except Exception as e:
        get_logger().error(f"Failed to resolve bot user ID: {e}")
        return None

async def is_bot_assigned_as_reviewer(data) -> bool:
    try:
        changes = data.get("changes")
        if not isinstance(changes, dict):
            return False
        if "reviewers" not in changes:
            return False
        reviewers_change = changes["reviewers"]
        if not isinstance(reviewers_change, dict):
            return False
        previous = reviewers_change.get("previous")
        if not isinstance(previous, list):
            previous = []
        current = reviewers_change.get("current")
        if not isinstance(current, list):
            current = []
        bot_user_id = await _get_bot_user_id()
        if bot_user_id is None:
            return False
        previous_ids = {r.get("id") for r in previous if isinstance(r, dict)}
        current_ids = {r.get("id") for r in current if isinstance(r, dict)}
        return bot_user_id in current_ids and bot_user_id not in previous_ids
    except Exception as e:
        get_logger().error(f"Failed 'is_bot_assigned_as_reviewer' logic: {e}")
    return False

def should_process_pr_logic(data) -> bool:
    return shared_should_process_pr_logic(data, provider="gitlab")


def authenticate_gitlab_webhook(request: Request, log_context: dict):
    request_token = request.headers.get("X-Gitlab-Token")
    # Built only for a request that will actually consult it, so a cloud client that
    # fails to initialize or read cannot drop webhooks authenticated by shared secret instead.
    secret = None
    if request_token:
        try:
            secret_provider = get_fork_safe_secret_provider()
            secret = secret_provider.get_secret(request_token) if secret_provider else None
        except Exception as e:
            get_logger().warning(f"Secret provider failed ({type(e).__name__}), falling back to the shared secret")
    if secret:
        try:
            secret_dict = json.loads(secret)
            context["settings"].gitlab.personal_access_token = secret_dict["gitlab_token"]
            log_context["token_id"] = secret_dict.get("token_name", secret_dict.get("id", "unknown"))
        except Exception as e:
            get_logger().error(
                f"Failed to validate the secret for the provided webhook token: {type(e).__name__}")
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                                content=jsonable_encoder({"message": "unauthorized"}))
    elif get_settings().get("GITLAB.SHARED_SECRET"):
        secret = get_settings().get("GITLAB.SHARED_SECRET")
        if not hmac.compare_digest(str(request_token or ""), str(secret)):
            get_logger().error("Failed to validate secret")
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                                content=jsonable_encoder({"message": "unauthorized"}))
    else:
        get_logger().error("Failed to validate secret")
        return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                            content=jsonable_encoder({"message": "unauthorized"}))
    gitlab_token = get_settings().get("GITLAB.PERSONAL_ACCESS_TOKEN", None)
    if not gitlab_token:
        get_logger().error("No gitlab token found")
        return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                            content=jsonable_encoder({"message": "unauthorized"}))
    return None


@router.post("/webhook")
async def gitlab_webhook(background_tasks: BackgroundTasks, request: Request):
    start_time = datetime.now()
    request_json = await request.json()
    context["settings"] = copy.deepcopy(global_settings)

    log_context = {"server_type": "gitlab_app"}
    get_logger().debug("Received a GitLab webhook")
    unauthorized_response = authenticate_gitlab_webhook(request, log_context)
    if unauthorized_response is not None:
        return unauthorized_response

    async def inner(data: dict):
        get_logger().info("GitLab data", artifact=data)
        sender = data.get("user", {}).get("username", "unknown")
        sender_id = data.get("user", {}).get("id", "unknown")

        # ignore bot users
        if is_bot_user(data):
            return

        log_context["sender"] = sender
        if data.get('object_kind') == 'merge_request':
            # ignore MRs based on title, labels, source and target branches
            if not should_process_pr_logic(data):
                return
            object_attributes = data.get('object_attributes', {})
            if object_attributes.get('action') in ['open', 'reopen']:
                url = object_attributes.get('url')
                get_logger().info(f"New merge request: {url}")
                apply_repo_settings(url)
                await _perform_commands_gitlab("pr_commands", PRAgent(), url, log_context, data)

            # for draft to ready triggered merge requests, before the push case: one update can be both
            elif object_attributes.get('action') == 'update' and is_draft_ready(data):
                url = object_attributes.get('url')
                get_logger().info(f"Draft MR is ready: {url}")

                apply_repo_settings(url)
                if get_settings().get("gitlab.feedback_on_draft_pr", False):
                    # the draft was already getting feedback, so only the push half of this update is new
                    if (object_attributes.get('oldrev')
                            and get_settings().get("gitlab.push_commands", {})
                            and get_settings().get("gitlab.handle_push_trigger", False)):
                        get_logger().debug(f'A push event has been received: {url}')
                        async with push_trigger_slot(url, allow_backlog=True, ttl=300) as proceed:
                            if proceed:
                                await _perform_commands_gitlab("push_commands", PRAgent(), url, log_context, data)
                    else:
                        get_logger().info(f"Skipping draft-ready commands because draft feedback is enabled: {url}")
                    return
                await _perform_commands_gitlab("pr_commands", PRAgent(), url, log_context, data)

            # for push event triggered merge requests
            elif object_attributes.get('action') == 'update' and object_attributes.get('oldrev'):
                url = object_attributes.get('url')
                get_logger().info(f"New merge request: {url}")
                # Apply repo settings before checking push commands or handle_push_trigger
                apply_repo_settings(url)

                commands_on_push = get_settings().get("gitlab.push_commands", {})
                handle_push_trigger = get_settings().get("gitlab.handle_push_trigger", False)
                if not commands_on_push or not handle_push_trigger:
                    get_logger().info("Push event, but no push commands found or push trigger is disabled")
                    return

                get_logger().debug(f'A push event has been received: {url}')
                async with push_trigger_slot(url, allow_backlog=True, ttl=300) as proceed:
                    if proceed:
                        await _perform_commands_gitlab("push_commands", PRAgent(), url, log_context, data)

            # for reviewer assignment triggered merge requests
            elif object_attributes.get('action') == 'update' and not object_attributes.get('oldrev'):
                url = object_attributes.get('url')
                if not url:
                    return JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"message": "success"}))

                # Fast early-exit: no reviewer changes means nothing to do
                changes = data.get("changes")
                if not isinstance(changes, dict) or "reviewers" not in changes:
                    return JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"message": "success"}))

                apply_repo_settings(url)
                handle_assignment = get_settings().get("gitlab.handle_reviewer_assignment", False)
                if isinstance(handle_assignment, str):
                    handle_assignment = handle_assignment.lower() in ("true", "1", "yes")
                if not handle_assignment:
                    return JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"message": "success"}))

                # Check PR logic after applying repo settings
                if not should_process_pr_logic(data):
                    return JSONResponse(
                        status_code=status.HTTP_200_OK, content=jsonable_encoder({"message": "success"}))

                if is_draft(data):
                    get_logger().info(f"Skipping draft MR reviewer assignment: {url}")
                    return JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"message": "success"}))
                if await is_bot_assigned_as_reviewer(data):
                    reviewer_commands = get_settings().get("gitlab.reviewer_commands", [])
                    if (not isinstance(reviewer_commands, list)
                            or not all(isinstance(c, str) for c in reviewer_commands)):
                        get_logger().warning("gitlab.reviewer_commands is not a list of strings, skipping")
                        return JSONResponse(status_code=status.HTTP_200_OK,
                                            content=jsonable_encoder({"message": "success"}))
                    get_logger().info(f"Bot was assigned as reviewer on MR: {url}")
                    await _perform_commands_gitlab("reviewer_commands", PRAgent(), url, log_context, data)

        elif data.get('object_kind') == 'note' and data.get('event_type') == 'note': # comment on MR
            if 'merge_request' in data:
                mr = data['merge_request']
                url = mr.get('url')
                comment_id = data.get('object_attributes', {}).get('id')
                provider = get_git_provider_with_context(pr_url=url)

                get_logger().info(f"A comment has been added to a merge request: {url}")
                body = data.get('object_attributes', {}).get('note')
                if data.get('object_attributes', {}).get('type') == 'DiffNote' and '/ask' in body: # /ask_line
                    body = handle_ask_line(body, data)

                await handle_request(
                    url, body, log_context, sender_id, notify=lambda: provider.add_eyes_reaction(comment_id))

    background_tasks.add_task(inner, request_json)
    end_time = datetime.now()
    get_logger().info(f"Processing time: {end_time - start_time}", request=request_json)
    return JSONResponse(status_code=status.HTTP_200_OK, content=jsonable_encoder({"message": "success"}))


def handle_ask_line(body, data):
    try:
        line_range_ = data['object_attributes']['position']['line_range']
        if line_range_['start'].get('type', 'new') == 'old':
            start_line = line_range_['start']['old_line']
            end_line = line_range_['end']['old_line']
            side = 'LEFT'
        else:
            start_line = line_range_['start']['new_line']
            end_line = line_range_['end']['new_line']
            side = 'RIGHT'
        question = body.strip().removeprefix('/ask').strip()
        path = data['object_attributes']['position']['new_path']
        comment_id = data['object_attributes']["discussion_id"]
        get_logger().info("Handling line ")
        body = [
            "/ask_line",
            f"--line_start={start_line}",
            f"--line_end={end_line}",
            f"--side={side}",
            f"--file_name={path}",
            f"--comment_id={comment_id}",
        ]
        if question:
            body.append(question)
    except Exception as e:
        get_logger().error(f"Failed to handle ask line comment: {e}")
    return body


@router.get("/")
async def root():
    return {"status": "ok"}

gitlab_url = get_settings().get("GITLAB.URL", None)
if not gitlab_url:
    raise ValueError("GITLAB.URL is not set")
get_settings().config.git_provider = "gitlab"
middleware = [Middleware(RawContextMiddleware)]
if prometheus_metrics_enabled():
    attach_metrics_endpoint(router)
app = FastAPI(middleware=middleware)
app.include_router(router)


def start():
    """
    Start the GitLab webhook server.

    The server port can be configured via the PORT environment variable.
    Defaults to 3000 if PORT is not set or invalid.
    """
    raw_port = os.environ.get("PORT")
    try:
        port = int(raw_port) if raw_port else 3000
        if not (1 <= port <= 65535):
            raise ValueError(f"Port {port} is out of valid range")
        if raw_port:
            get_logger().info(f"Using custom PORT from environment: {port}")
    except ValueError as e:
        get_logger().warning(f"Invalid PORT environment variable ({e}), using default port 3000")
        port = 3000
    uvicorn.run(app, host="0.0.0.0", port=port)


if __name__ == '__main__':
    start()
