# Usage guide

This section provides a detailed guide on how to use PR-Agent.
It includes information on how to adjust PR-Agent configurations, define which tools will run automatically, and other advanced configurations.

- [Introduction](./introduction.md)
- [Configuration File](./configuration_options.md)
- [Configuration Reference](./configuration_reference.md)
- [Usage and Automation](./automations_and_usage.md)
    - [Local Repo (CLI)](./automations_and_usage.md#local-repo-cli)
    - [Online Usage](./automations_and_usage.md#online-usage)
    - [GitHub App](./automations_and_usage.md#github-app)
    - [GitHub Action](./automations_and_usage.md#github-action)
    - [GitLab Webhook](./automations_and_usage.md#gitlab-webhook)
    - [Gitea Webhook](./automations_and_usage.md#gitea-webhook)
    - [BitBucket App](./automations_and_usage.md#bitbucket-app)
    - [Azure DevOps Provider](./automations_and_usage.md#azure-devops-provider)
- [Managing Mail Notifications](./mail_notifications.md)
- [Push Outputs](./push_outputs.md)
- [Changing a Model](./changing_a_model.md)
- [Additional Configurations](./additional_configurations.md)
    - [Ignoring files from analysis](./additional_configurations.md#ignoring-files-from-analysis)
    - [Extra instructions](./additional_configurations.md#extra-instructions)
    - [Changing a model](./changing_a_model.md)
- [FAQ](../faq/index.md)
